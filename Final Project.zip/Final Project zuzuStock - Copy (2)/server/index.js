/**server/index.js */
const express = require("express");
const cors = require("cors");
const productsRouter = require("./routers/products-router.js");
const userRouter = require("./routers/userRoutes.js");
const categoryRouter = require("./routers/categoryRoutes.js");
const orderRouter = require("./routers/order-router.js");
const reportRouter = require("./routers/report-router.js"); // Import the report-router

// Creating the Express application
const app = express();
// Setting up the port on which the server will listen

const port = 3001;

// Setting up middleware for serving static files from the public folder
app.use(express.static("public"));
const corsOptions = {
  origin: "*", // Replace with the actual client URL
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
};
// Parsing incoming JSON data
app.use(cors(corsOptions));

// Parsing incoming JSON data
app.use(express.json());

// Setting up routes for products, users, and categories
app.use("/api/products", productsRouter);
app.use("/api/users", userRouter);
app.use("/api/categories", categoryRouter);
app.use("/api/orders", orderRouter);
app.use("/api/reports", reportRouter);
// Starting the server and listening on the specified port
app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});
