/**server/middlewares/db.js */
const mysql = require("mysql2");

// Function to establish a connection with the MySQL database
const dbConnect = () => {
  // Creating a connection with the database using the provided configuration
  const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
   
    database: "zuzustock",
  });

  // Connecting to the database

  db.connect((err) => {
    if (err) {
      console.log("error connecting: " + err.stack);
      return;
    }

    console.log("Connected to Database successfully");
  });

  // Returning the connection object to be used for executing queries

  return db;
};

// Exporting the database connection function to be used in other parts of the application

const db = dbConnect();

module.exports = { db };
