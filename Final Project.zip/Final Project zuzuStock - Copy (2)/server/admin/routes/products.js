/**server/admin/routes/products.js */
const express = require("express");
const router = express.Router();
const Product = require("../../models/Product"); // Import your Product model

// Route to fetch all products
router.get("/", async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
