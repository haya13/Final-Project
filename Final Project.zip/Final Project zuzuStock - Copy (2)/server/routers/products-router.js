/** server/routers/products-router.js */
const express = require("express");
const router = express.Router();
const {
  getProducts,
  createProduct,
  updateProduct,
  deleteProduct,
  getMostSoldProducts,
} = require("../controllers/products-controller.js");
const {
  getProductsByCategory,
} = require("../controllers/categoryController.js");

// Route to handle GET requests for retrieving all products
router.get("/", getProducts);
router.get("/most-sold", getMostSoldProducts);

// Route to handle GET requests for retrieving a specific product by ID (Not implemented)
router.get("/:categoryName", getProductsByCategory);

// Route to handle POST requests for creating a new product (Not implemented)
router.post("/", createProduct);

// Route to handle PUT requests for updating a product by ID (Not implemented)
router.put("/", updateProduct);

// Route to handle DELETE requests for deleting a product by ID
router.delete("/:productId", deleteProduct);

module.exports = router;
