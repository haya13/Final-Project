/** server/routers/categoryRoutes.js */
const express = require("express");
const {
  getProductsByCategory,
  getCategories,
} = require("../controllers/categoryController");
const router = express.Router();

// Route to handle GET requests for retrieving all categories

router.get("/", getCategories);

// Route to handle GET requests for retrieving products by a specific category name

router.get("/:categoryName", getProductsByCategory);

// Exporting the router object to be used in the main application
module.exports = router;
