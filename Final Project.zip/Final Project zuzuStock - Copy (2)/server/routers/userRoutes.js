/**server/routers/userRoutes.js */
const express = require("express");
const router = express.Router();

// Import the user controller functions
const {
  registerUser,
  loginUser,
  getAllUsers,
  updateUser,
} = require("../controllers/userController.js");

// Route to handle POST requests for user registration
router.post("/", registerUser);

// Route to handle POST requests for user login
router.post("/login", loginUser);

// Route to handle GET requests to fetch all registered users
router.get("/users", getAllUsers);

router.put("/", updateUser);

module.exports = router;
