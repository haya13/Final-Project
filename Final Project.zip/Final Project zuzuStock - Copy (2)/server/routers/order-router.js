/** server/routers/order-router.js */
const express = require("express");
const {
  addOrder,
  getAllOrders,
  deleteOrder,
} = require("../controllers/order-controller");
const router = express.Router();

// Route to handle GET requests for retrieving all categories
router.get("/", getAllOrders);
router.post("/", addOrder);
router.delete("/:id", deleteOrder);
// Route to handle DELETE requests for deleting an order

// Route to handle GET requests for retrieving products by a specific category name

// Exporting the router object to be used in the main application
module.exports = router;
