const express = require("express");
const router = express.Router();
const {
  generateDailyReport,
  generateMonthlyReport,
} = require("../controllers/reportController"); // Update with the correct path to your report controller

// Routes for generating reports
router.get("/daily", generateDailyReport);
router.get("/monthly", generateMonthlyReport);

module.exports = router;
