const { db } = require("../middlewares/db");

const getAllOrders = (req, res) => {
  db.query(`SELECT * FROM \`order\``, (err, orders) => {
    if (err) {
      console.log("Error getting orders:", err);
      return res.status(500).json({ error: "Error getting orders" });
    }
    db.query(`SELECT * FROM \`order_details\``, (err, items) => {
      if (err) {
        console.log("Error getting orders:", err);
        return res.status(500).json({ error: "Error getting orders" });
      }

      for (const order of orders) {
        order.items = [];
        for (const item of items) {
          if (item.order_id === order.id) {
            order.items.push(item);
          }
        }
      }

      res.json(orders);
    });
  });
};

const addOrder = (req, res) => {
  const { cart, user } = req.body;

  const { totalPrice, totalItemsQuantity } = cart.reduce(
    (acc, item) => {
      acc.totalPrice += item.Product_Price * item.quantity;
      acc.totalItemsQuantity += item.quantity;
      return acc;
    },
    { totalPrice: 0, totalItemsQuantity: 0 }
  );

  const address = `${user.Street}, ${user.City}, ${user.Zip}`;
  db.query(
    `INSERT INTO \`order\` (Order_Date, Final_Price, Destination_Address, TotalItemsQuantity, Order_Owner ) VALUES (?, ?, ?, ?, ?)`,
    [new Date(), totalPrice, address, totalItemsQuantity, user.Email],
    (err, result) => {
      if (err) {
        console.log("Error inserting order:", err);
        return res.status(500).json({ error: "Error inserting order" });
      }
      const orderId = result.insertId;
      res.json({ orderId });

      const orderDetailsQuery = `INSERT INTO order_details (order_id, item_id, quantity) VALUES ?`;
      const orderItems = cart.map((item) => [orderId, item.id, item.quantity]);

      db.query(orderDetailsQuery, [orderItems], (err, result) => {
        if (err) {
          console.log("Error inserting order items:", err);
        } else {
          console.log("Order items inserted successfully.");
        }
      });

      const idArray = [];
      let orId = "";
      cart.forEach((item, index) => {
        if (index !== 0) {
          orId += " OR ";
        }
        orId += `id = ?`;
        idArray.push(item.id);
      });

      const query = `UPDATE product SET Product_Amount = Product_Amount - 1 
      WHERE ${orId}`;
      console.log("query", query);
      db.query(query, idArray, (err, result) => {
        if (err) {
          console.log("Error updating product quantity:", err);
        }
      });
    }
  );
};

const deleteOrder = (req, res) => {
  const orderId = req.params.id;

  db.query(`DELETE FROM \`order\` WHERE id = ?`, [orderId], (err, result) => {
    if (err) {
      console.log("Error deleting order:", err); // Log the error message
      return res.status(500).json({ error: "Error deleting order" });
    }

    res.sendStatus(200);
  });
};

module.exports = { addOrder, getAllOrders, deleteOrder };
