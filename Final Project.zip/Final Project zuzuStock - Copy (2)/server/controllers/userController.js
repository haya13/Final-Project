/**server/controllers/userController.js */
const { db } = require("../middlewares/db");
const bcrypt = require("bcrypt");

async function hashPassword(password) {
  // Random bytes generation
  const salt = await bcrypt.genSalt(); // default 10
  const hashed = await bcrypt.hash(password, salt); // each time different
  return hashed;
}

// Function to create a new user
const registerUser = async (req, res) => {
  const { firstName, lastName, street, city, zipCode, email, password } =
    req.body;
  const hashed = await hashPassword(password);

  const query = `INSERT INTO customer (First_Name, Last_Name, Street, City, Zip, Email, Password) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)`;

  db.query(
    query,
    [firstName, lastName, street, city, zipCode, email, hashed],
    (err, result) => {
      if (err) {
        console.log("Error inserting user:", err);
        if (err.code === "ER_DUP_ENTRY") {
          return res
            .status(409)
            .json({ error: "Email address already exists" });
        }

        return res.status(500).json({ error: "Error inserting user" });
      }
      console.log("User registered successfully!");
      return res.status(201).json({ message: "User registered successfully" });
    }
  );
};
const loginUser = (req, res) => {
  console.log(req.body);
  const { email, password } = req.body;

  const query = "SELECT * FROM customer WHERE Email = ?";
  db.query(query, [email, password], (err, result) => {
    if (err) {
      console.log("Error fetching user:", err);
      return res.status(500).json({ error: "Error fetching user" });
    }

    if (result.length === 0) {
      // No user found with the given email and password
      return res.status(401).json({ error: "Invalid email or password" });
    }

    // User found with the given email and password
    const hashed = result[0].Password;
    const comparisonResult = bcrypt.compareSync(password, hashed);

    if (!comparisonResult) {
      // Passwords don't match
      return res.status(401).json({ error: "Invalid email or password" });
    }

    console.log("User logged in successfully!");

    // Modify the response to include the user_status and user object
    const user = result[0];
    return res.status(200).json({
      message: "User logged in successfully",
      user_status: user.user_status,
      user: user, // Include the user object here
    });
  });
};

// Function to fetch all registered users
const getAllUsers = (req, res) => {
  const query = "SELECT * FROM customer";

  db.query(query, (err, result) => {
    if (err) {
      console.log("Error fetching users:", err);
      return res.status(500).json({ error: "Error fetching users" });
    }

    console.log("Users fetched successfully!");
    return res.status(200).json(result);
  });
};

const updateUser = (req, res) => {
  const { firstName, lastName, street, city, zipCode, email } = req.body;

  const query = `UPDATE customer SET First_Name = ?, Last_Name = ?, Street = ?, City = ?, Zip = ? WHERE Email = ?`;

  db.query(
    query,
    [firstName, lastName, street, city, zipCode, email],
    (err, result) => {
      if (err) {
        console.log("Error updating user:", err);
        return res.status(500).json({ error: "Error updating user" });
      }

      console.log("User updated successfully!");
      return res.status(200).json({ message: "User updated successfully" });
    }
  );
};

module.exports = { registerUser, loginUser, getAllUsers, updateUser };
