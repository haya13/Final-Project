/**server/controllers/categoryController.js */

const { db } = require("../middlewares/db");

const getCategories = (req, res) => {
  let query = "SELECT Category_Name FROM category";

  // Using database query to retrieve categories
  db.query(query, (err, rows) => {
    if (err) {
      console.error("Error fetching categories:", err);
      return res.status(500).json({ error: "Error fetching categories" });
    }

    // Returning the list of categories as a JSON response with a success message
    return res.status(200).json({ categories: rows, message: "Success" });
  });
};

// Controller function to get products by a specific category from the database

const getProductsByCategory = async (req, res) => {
  const categoryName = req.params.categoryName;

  // Query to join the product and category tables and retrieve products of the given category

  let query = `SELECT category.Category_Name,product.*
    FROM product
    INNER JOIN category ON product.Category=category.Category_Name AND category.Category_Name='${categoryName}';`;

  // Using Promise-based database query to retrieve products

  db.promise()
    .query(query)
    .then((rows) => {
      // Returning the list of products of the specified category as a JSON response with a success message

      return res
        .status(200)
        .json({ products: rows[0], message: "Products sent" });
    })
    .catch((err) => console.log(err));
};

// Exporting the controller functions to be used in the routes
module.exports = { getProductsByCategory, getCategories };

{
  /**These controller functions handle the logic for retrieving categories and products by category from the database and respond with JSON data to the client.
   */
}
