/**server/controllers/reportController.js */
const db = require("../middlewares/db");

const generateDailyReport = (req, res) => {
    try {
        // Your code to generate the daily report
    } catch (error) {
        console.error("Error generating daily report:", error);
        res.status(500).json({ error: "Error generating daily report" });
    }
};


const generateMonthlyReport = (req, res) => {
    console.log("Generating monthly report...");

  db.query(
    `SELECT SUM(Final_Price) AS revenue FROM \`order\` WHERE YEAR(Order_Date) = YEAR(CURDATE()) AND MONTH(Order_Date) = MONTH(CURDATE())`,
    (err, result) => {
      if (err) {
        console.log("Error generating monthly report:", err);
        return res
          .status(500)
          .json({ error: "Error generating monthly report" });
      }

      const monthlyRevenue = result[0].revenue || 0;
      res.json({ revenue: monthlyRevenue });
    }
  );
};

module.exports = { generateDailyReport, generateMonthlyReport };
