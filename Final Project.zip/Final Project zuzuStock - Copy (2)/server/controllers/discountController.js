// server/controllers/discountController.js
const { db } = require("../middlewares/db");

const applyDiscount = async (req, res) => {
  try {
    console.log("Request received to apply discount");

    const { productIds, discountValue } = req.body;

    // Create a string of placeholders for the productIds
    const placeholders = productIds.map(() => "?").join(",");

    // Fetch the current product prices
    const getProductQuery = `SELECT id, Product_Price FROM product WHERE id IN (${placeholders})`; // Updated table name
    const products = await db.query(getProductQuery, productIds);

    // Update the product prices and build an array of updated products
    const updatedProducts = products.map((product) => {
      const discountedPrice = product.Product_Price * (1 - discountValue);
      return {
        id: product.id,
        Product_Price: discountedPrice,
      };
    });

    // Update the product prices in the database
    const updateProductQuery = `
      UPDATE product
      SET Product_Price = CASE
        ${updatedProducts.map((product) => `WHEN id = ? THEN ?`).join(" ")}
      END
      WHERE id IN (${placeholders})
    `;

    const updateValues = updatedProducts.flatMap((product) => [
      product.id,
      product.Product_Price,
    ]);

    await db.query(updateProductQuery, updateValues);

    res.status(200).json({ message: "Discount applied successfully" });
  } catch (error) {
    console.error("Error applying discount:", error);
    res.status(500).json({ message: "Error applying discount" });
  }
};

module.exports = { applyDiscount };
