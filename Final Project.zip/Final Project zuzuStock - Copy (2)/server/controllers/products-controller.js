/**server/controllers/products-controller.js */

// const mysql = require("mysql2");
const { db } = require("../middlewares/db");
// Sample data for products (This will be replaced with data fetched from the database)

// Controller function to get all products from the database
const getProducts = async (req, res) => {
  let products_arr = [];
  // Using a database query to retrieve all products from the database
  db.query("SELECT * FROM product", async (err, rows) => {
    if (err) {
      console.log("Error fetching products:", err);

      return res.status(500).json({ error: "Error fetching products" });
    }

    // Transforming the retrieved database rows into the desired products array format
    await rows.forEach((value) => {
      products_arr.push(value);
    });
    console.log("Products fetched successfully!");

    // Sending the products array as a JSON response with a testing message
    return res.send({ products: products_arr, message: "testing" });
  });
};

const getMostSoldProducts = async (req, res) => {
  db.query(
    `SELECT
  p.Product_Name AS Product_Title,
  SUM(od.quantity) AS Purchased_Amount
FROM
  product p
JOIN
  order_details od ON p.id = od.item_id
GROUP BY
  p.Product_Name;`,
    async (err, products) => {
      if (err) {
        console.log("Error fetching products:", err);

        return res.status(500).json({ error: "Error fetching products" });
      }

      return res.send(products);
    }
  );
};

const createProduct = async (req, res) => {
  // Destructuring the product object from the request body
  const { id, name, price, description, color, stock, category } = req.body;

  // Using a database query to insert a new product into the database
  db.query(
    "INSERT INTO product (id, Product_Name," +
      " Product_Price, Product_Description, Product_Color, Product_Amount, Category) VALUES (?, ?, ?, ?, ?, ?, ?)",
    [id, name, price, description, color, stock, category],
    (err, result) => {
      if (err) {
        console.log("Error creating product:", err);

        return res.status(500).json({ error: "Error creating product" });
      }

      console.log("Product created successfully!");

      // Sending a success response with the ID of the newly created product

      return res.status(201).json({ id: result.insertId });
    }
  );
};

const updateProduct = async (req, res) => {
  // Destructuring the product object from the request body
  const { id, name, price, description, color, stock, category, imageUrl } =
    req.body;
  console.log("req.body", req.body);

  // Using a database query to update an existing product in the database
  db.query(
    "UPDATE product SET Product_Name = ?, Product_Price = ?, Product_Description = ?, Product_Color = ?, Product_Amount = ?, Category = ?, Image_URL= ? WHERE id = ?",
    [name, price, description, color, stock, category, imageUrl, id],
    (err, result) => {
      if (err) {
        console.log("Error updating product:", err);

        return res.status(500).json({ error: "Error updating product" });
      }

      console.log("Product updated successfully!");

      // Sending a success response with the ID of the updated product

      return res.status(200).json({ id: result.insertId });
    }
  );
};

const deleteProduct = async (req, res) => {
  // Destructuring the product ID from the request parameters
  const { productId } = req.params;

  // Using a database query to delete an existing product from the database
  db.query("DELETE FROM product WHERE id = ?", [productId], (err, result) => {
    if (err) {
      console.log("Error deleting product:", err);

      return res.status(500).json({ error: "Error deleting product" });
    }
    console.log("Product deleted successfully!");
    // Sending a success response with the ID of the deleted product
    return res.status(200).json({ id: result.insertId });
  });
};

// Exporting the controller function to be used in the routes
module.exports = {
  getProducts,
  createProduct,
  updateProduct,
  deleteProduct,
  getMostSoldProducts,
};
