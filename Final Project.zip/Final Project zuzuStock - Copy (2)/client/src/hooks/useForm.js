/** client/src/hooks/useForm.js*/
export default function useForm(args) {
  // Define a function to handle changes in input fields
  const handleChange = (event) => {
    // Loop through all the properties of the first argument (userValue)
    console.log("Form submitted!");
    for (const [key] of Object.entries(args[0])) {
      // If the key matches the ID of the target input element, update its value
      if (key.toString() === event.target.id) {
        const tmp = args[0];
        tmp[key] = event.target.value;
        // Call the setter function (setUserValue) with the updated temporary object
        args[1]({ ...tmp });
      }
    }
  };

  // Define a function to handle form submissions
  const handleSubmit = (event) => {
    event.preventDefault(); // Prevent default form submission
    // Call the onsubmit function provided in the third argument with the event object
    args[2].onsubmit(event);
  };

  // Return an object containing the handleChange and handleSubmit functions
  return {
    handleChange: handleChange,
    handleSubmit: handleSubmit,
    name: "Haya", 
  };
}
