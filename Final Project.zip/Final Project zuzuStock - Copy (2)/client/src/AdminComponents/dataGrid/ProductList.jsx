/*client\src\AdminComponents\dataGrid\ProductList.jsx */
import React, { useState, useEffect } from "react";
import { MdOutlineSearch } from "react-icons/md";
import axios from "axios";
import "./productList.css";

export const ProductList = ({ setEditedProduct, products, fetchProducts }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [isProductListVisible, setIsProductListVisible] = useState(false);
  const [filterField, setFilterField] = useState("");
  const [filterValue, setFilterValue] = useState("");

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const toggleProductList = () => {
    setIsProductListVisible(!isProductListVisible);
  };

  const applyFilter = () => {
    const filteredProducts = products.filter((product) => {
      if (!filterField || !filterValue) {
        return true; // Show all products if no filter is applied
      }

      const fieldMatches = product[filterField]
        .toLowerCase()
        .includes(filterValue.toLowerCase());

      return fieldMatches;
    });

    return filteredProducts;
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const filteredProducts = applyFilter().filter((product) =>
    product.Product_Name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDelete = (id) => {
    axios
      .delete(`/api/products/${id}`)
      .then((res) => {
        console.log("res", res.data);
        fetchProducts();
      })
      .catch((err) => console.log(err));
  };

  return (
    <div id="productList" className="data-grid-feature">
      <div>
        <h2>
          Products List{" "}
          <button onClick={toggleProductList}>
            {isProductListVisible ? "Hide" : "Show"} Product List
          </button>
        </h2>
      </div>

      {isProductListVisible && (
        <div>
          <div className="filter-bar">
            <h3>Filter By : </h3>
            <select
              value={filterField}
              onChange={(e) => setFilterField(e.target.value)}
            >
              <option value="">None</option>
              <option value="id">ID</option>
              <option value="Product_Name">Name</option>
              <option value="Category">Category</option>
              <option value="Product_Price">Price</option>
              <option value="Product_Color">Color</option>
              <option value="Product_Amount">Amount</option>
              <option value="isOnSale">On Sale</option>
            </select>
            <input
              type="text"
              placeholder="Enter filter value..."
              value={filterValue}
              onChange={(e) => setFilterValue(e.target.value)}
            />
          </div>

          <div className="product-list">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Catgeory</th>
                  <th>Name</th>
                  <th>Price</th>
                  <th>Color</th>
                  <th>Amount</th>
                  <th>On Sale</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map((product) => (
                  <tr key={product.id}>
                    <td>{product.id}</td>
                    <td>{product.Category}</td>
                    <td>{product.Product_Name}</td>
                    <td>{product.Product_Price}</td>
                    <td>{product.Product_Color}</td>
                    <td>{product.Product_Amount}</td>
                    <td>{product.isOnSale}</td>
                    <td>
                      <button
                        className="edit-button"
                        onClick={() => setEditedProduct(product)}
                      >
                        Edit
                      </button>
                      <button
                        className="delete-button"
                        onClick={() => handleDelete(product.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductList;
