/**client/src/AdminComponents/dataGrid/CityTable.jsx*/
import React, { useEffect, useState } from "react";
import { getAllUsers } from "../../services/userService";
import { Line } from "react-chartjs-2";
import "chart.js/auto";

const CityTable = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    // Fetch all registered users when the component mounts
    getAllUsers()
      .then((res) => {
        setUsers(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  // Process the data to count the number of users from each city
  const cityCounts = {};
  users.forEach((user) => {
    const city = user.City;
    if (city in cityCounts) {
      cityCounts[city]++;
    } else {
      cityCounts[city] = 1;
    }
  });

  // Convert cityCounts object to an array of objects
  const cityCountsArray = Object.keys(cityCounts).map((city) => ({
    city: city,
    count: cityCounts[city],
  }));

  // Sort the cityCountsArray by count in descending order
  cityCountsArray.sort((a, b) => b.count - a.count);

  // Chart data
  const data = {
    labels: cityCountsArray.map((cityObj) => cityObj.city),
    datasets: [
      {
        label: "Number of Users",
        data: cityCountsArray.map((cityObj) => cityObj.count),
        backgroundColor: "rgb(150,75,0)",
        borderColor: "rgb(150,75,0)",
        borderWidth: 3,
        pointBackgroundColor: "rgb(150,75,0)",
        pointBorderColor: "rgb(150,75,0)",
        pointHoverBackgroundColor: "rgb(150,75,0)",
        pointHoverBorderColor: "rgb(150,75,0)",
      },
    ],
  };

  const options = {
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <div className="chart-container">
      <br />
      <div className="line-chart" style={{ width: "400", height: "400" }}>
        <Line data={data} options={options} />
      </div>
    </div>
  );
};

export default CityTable;
