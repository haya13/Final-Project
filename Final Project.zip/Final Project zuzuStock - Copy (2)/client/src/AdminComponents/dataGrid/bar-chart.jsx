/**client/src/AdminComponents/dataGrid/bar-chart.jsx*/
import React, { useEffect, useState } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Bar } from "react-chartjs-2";
import axios from "axios";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export const options = {
  responsive: true,
  plugins: {
    legend: {
      position: "top",
    },
  },
};

export function BarChart() {
  const [mostPurchase, setMostPurchase] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3001/api/products/most-sold").then((res) => {
      const data = {};
      const items = res.data;
      items.sort((a, b) => b.Purchased_Amount - a.Purchased_Amount);

      for (const item of items.slice(0, 5)) {
        const amount = item.Purchased_Amount;
        console.log("amount", amount);
        data[item.Product_Title] = Number(amount);
      }
      setMostPurchase(data);
      console.log("data", data);
    });
  }, []);

  const data = {
    labels: Object.keys(mostPurchase),
    datasets: [
      {
        label: "Most purchased items",
        data: Object.values(mostPurchase),
        backgroundColor: "rgb(150,75,0)",
      },
    ],
  };

  return (
    <div>
      <Bar options={options} data={data} />
    </div>
  );
}
