// client/src/AdminComponents/dataGrid/ProductDetails.js

import React from "react";
import "./productDetails.css"; // Import your custom CSS file

const ProductDetails = ({ selectedProduct }) => {
  return (
    <div className="product-details-container">
      <h2>Product Details</h2>
      <div className="product-details">
        <div className="product-image">
          {selectedProduct.image ? (
            <img src={selectedProduct.image} alt={selectedProduct.name} />
          ) : null}
        </div>
        <div className="product-info">
          <h3>{selectedProduct.name}</h3>
          <p>{selectedProduct.description}</p>
          <p>Price: {selectedProduct.price}</p>
          <button className="add-to-cart-button">Add to Cart</button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
