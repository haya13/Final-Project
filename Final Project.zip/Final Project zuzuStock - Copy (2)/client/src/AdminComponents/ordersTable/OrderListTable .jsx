/*client\src\AdminComponents\ordersTable\OrderListTable .jsx */
import React, { useEffect, useState } from "react";
import axios from "axios";
import "./orderListTable.css";
import ReportGenerator from "../Reports/ReportGenerator";
import { Link, useParams } from "react-router-dom";
import { OrderModal } from "../OrderModal/OrderModal";
import { checkIsAdmin } from "../../utilities/isAdmin";

const OrderListTable = ({ products }) => {
  const [orders, setOrders] = useState([]);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [filterOption, setFilterOption] = useState("");
  const [filterValue, setFilterValue] = useState("");
  const [selectedOrder, setSelectedOrder] = useState(null);
  const { email } = useParams();

  useEffect(() => {
    // Fetch orders data from the server using axios
    axios
      .get("/api/orders") // Use the appropriate API endpoint
      .then((res) => {
        setOrders(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  const handleFilterByDate = () => {
    const filteredOrders = orders.filter((order) => {
      if (!startDate || !endDate) {
        return true; // Show all orders if dates are not selected
      }
      const orderDate = new Date(order.Order_Date);
      return orderDate >= startDate && orderDate <= endDate;
    });

    setOrders(filteredOrders);
  };

  const handleResetFilter = () => {
    setStartDate(null);
    setEndDate(null);
    setFilterOption("");
    setFilterValue("");
    setOrders([]); // Clear the orders array to fetch all orders again
    axios
      .get("/api/orders") // Fetch all orders
      .then((res) => {
        setOrders(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleApplyFilter = () => {
    let filteredOrders = [...orders];
    if (filterOption && filterValue) {
      filteredOrders = orders.filter((order) => {
        if (filterOption === "Final_Price") {
          return parseFloat(order[filterOption]) === parseFloat(filterValue);
        } else if (typeof order[filterOption] === "string") {
          return order[filterOption]
            .toLowerCase()
            .includes(filterValue.toLowerCase());
        } else {
          return (order[filterOption] = filterValue);
        }
      });
    }
    setOrders(filteredOrders);
  };

  const filteredOrders = email
    ? orders.filter((order) => order.Order_Owner === email)
    : orders;

  return (
    <>
      <div className="order-list-table">
        {/* Include the navbar */}
        {checkIsAdmin() && (
          <div className="navbar">
            <Link to="/admin/dashboard" className="nav-link">
              Dashboard
            </Link>
            <Link to="/admin/Orders" className="nav-link">
              Orders
            </Link>
            <Link to="/admin/Products" className="nav-link">
              Products
            </Link>
            <Link to="/admin/dataGrid" className="nav-link">
              Customers
            </Link>
          </div>
        )}
        <h2>Order List</h2>
        <div className="filter-controls">
          <div className="date-filter">
            <label>From: </label>
            <input
              type="date"
              value={startDate ? startDate.toISOString().substr(0, 10) : ""}
              onChange={(e) => setStartDate(new Date(e.target.value))}
            />
            <label>To:</label>
            <input
              type="date"
              value={endDate ? endDate.toISOString().substr(0, 10) : ""}
              onChange={(e) => setEndDate(new Date(e.target.value))}
            />
            <button onClick={handleFilterByDate}>Apply Date Filter</button>
          </div>
          <div className="column-filter">
            <label>Filter By:</label>
            <select
              value={filterOption}
              onChange={(e) => {
                setFilterOption(e.target.value);
                setFilterValue("");
              }}
            >
              <option value="">None</option>
              <option value="id">Order ID</option>
              <option value="TotalItemsQuantity">Total Items Quantity</option>
              <option value="Order_Owner">Customer Email</option>
              <option value="Destination_Address">Shipping Address</option>
              <option value="Final_Price">Price</option>
            </select>
            {filterOption && (
              <input
                type="text"
                placeholder={`Enter ${filterOption} to filter`}
                value={filterValue}
                onChange={(e) => setFilterValue(e.target.value)}
              />
            )}
            <button onClick={handleApplyFilter}>Apply Column Filter</button>
            <button onClick={handleResetFilter}>Reset Filters</button>
          </div>
        </div>
        <table>
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Date</th>
              <th>Final Price</th>
              <th>Shipping Address</th>
              <th>Total Items Quantity</th>
              <th>Customer Email</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filteredOrders
              .sort((a, b) => new Date(b.Order_Date) - new Date(a.Order_Date)) // Sort by order date in descending order
              .map((order) => (
                <tr key={order.id}>
                  <td>{order.id}</td>
                  <td>{new Date(order.Order_Date).toLocaleDateString()}</td>
                  <td>${parseFloat(order.Final_Price).toFixed(2)}</td>
                  <td>{order.Destination_Address}</td>
                  <td>{order.TotalItemsQuantity}</td>
                  <td>{order.Order_Owner}</td>
                  <td>
                    <button onClick={() => setSelectedOrder(order)}>
                      Show order
                    </button>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
        {checkIsAdmin() && (
          <div className="report-generator">
            <ReportGenerator />
          </div>
        )}
      </div>
      <OrderModal
        order={selectedOrder}
        setOrder={setSelectedOrder}
        products={products}
      />
    </>
  );
};

export default OrderListTable;
