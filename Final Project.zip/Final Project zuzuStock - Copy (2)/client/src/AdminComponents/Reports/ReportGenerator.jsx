import React, { useEffect, useState } from "react";
import axios from "axios";
import CsvProcessing from "../CSVProcessing/CsvProcessing";
import { saveAs } from "file-saver"; // Import the file-saver library

const ReportGenerator = () => {
  const [selectedMonth, setSelectedMonth] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [monthlyRevenue, setMonthlyRevenue] = useState(null);
  const [monthlyReport, setMonthlyReport] = useState([]);
  const [allTimeReport, setAllTimeReport] = useState([]);
  const [dailyReport, setDailyReport] = useState([]);
  const [errorMessage, setErrorMessage] = useState("");

  const generateCSV = (data, fileName) => {
    // Create the CSV content
    const csvContent =
      Object.keys(data[0]).join(",") +
      "\n" +
      data.map((item) => Object.values(item).join(",")).join("\n");

    // Create a Blob object from the CSV content
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8" });

    // Use the file-saver library to initiate the download
    saveAs(blob, fileName);
  };

  useEffect(() => {
    generateAllTimeReport();
  }, []);

  const generateAllTimeReport = () => {
    axios
      .get("/api/orders") // Fetch all orders
      .then((res) => {
        const orders = res.data;

        const reportData = orders.map((order) => ({
          Order_ID: order.id,
          Date: order.Order_Date,
          Final_Price: order.Final_Price,
          Shipping_Address: order.Destination_Address,
          Total_Items_Quantity: order.TotalItemsQuantity,
          Customer_Email: order.Order_Owner,
        }));

        setAllTimeReport(reportData);
      })
      .catch((err) => {
        console.log("Error fetching orders:", err);
      });
  };
  const generateMonthlyReport = () => {
    axios
      .get("/api/orders") // Fetch all orders
      .then((res) => {
        const orders = res.data;

        // Filter orders based on selected month
        const filteredOrders = selectedMonth
          ? orders.filter((order) => {
              return order.Order_Date.includes(selectedMonth);
            })
          : orders;

        // Calculate total revenue from filtered orders
        const totalRevenue = filteredOrders.reduce((total, order) => {
          return total + parseFloat(order.Final_Price);
        }, 0);

        // Prepare the monthly report data
        console.log("filteredOrders", filteredOrders);
        const reportData = filteredOrders.map((order) => ({
          Order_ID: order.id,
          Date: order.Order_Date,
          Final_Price: order.Final_Price,
          Shipping_Address: order.Destination_Address,
          Total_Items_Quantity: order.TotalItemsQuantity,
          Customer_Email: order.Order_Owner,
        }));
        console.log("reportData", reportData);

        setMonthlyRevenue(totalRevenue);
        setMonthlyReport(reportData);

        if (monthlyReport.length === 0) {
          setErrorMessage("No orders found for the selected month.");
        } else {
          setErrorMessage("");
        }
      })
      .catch((err) => {
        console.log("Error fetching orders:", err);
      });
  };

  const generateDailyReport = () => {
    axios
      .get("/api/orders") // Fetch all orders
      .then((res) => {
        const orders = res.data;

        const filteredOrders = selectedDate
          ? orders.filter((order) => {
              return order.Order_Date.includes(selectedDate);
            })
          : orders;

        const reportData = filteredOrders.map((order) => ({
          Order_ID: order.id,
          Date: order.Order_Date,
          Final_Price: order.Final_Price,
          Shipping_Address: order.Destination_Address,
          Total_Items_Quantity: order.TotalItemsQuantity,
          Customer_Email: order.Order_Owner,
        }));
        setDailyReport(reportData);

        if (dailyReport.length === 0) {
          setErrorMessage("No orders found for the selected date.");
        } else {
          setErrorMessage("");
        }
      })
      .catch((err) => {
        console.log("Error fetching daily report:", err);
      });
  };

  const handleGenerateMonthlyCSV = () => {
    if (monthlyReport.length > 0) {
      const fileName = `monthly_report_${selectedMonth}.csv`;
      generateCSV(monthlyReport, fileName);
    }
  };

  const handleGenerateDailyCSV = () => {
    if (dailyReport.length > 0) {
      const fileName = `daily_report_${selectedDate}.csv`;
      generateCSV(dailyReport, fileName);
    }
  };

  return (
    <div className="report-generator">
      <h2>Report Generator</h2>
      <CsvProcessing
        data={allTimeReport}
        fileName={`all_time_${selectedMonth}.csv`}
        buttonText="Generate all time CSV"
      />
      <div className="generate-buttons">
        <label>Select Month:</label>
        <input
          type="month"
          value={selectedMonth}
          onChange={(e) => setSelectedMonth(e.target.value)}
        />
        <button className="generate-button" onClick={generateMonthlyReport}>
          Generate Monthly Report
        </button>
      </div>

      {monthlyRevenue !== null && (
        <div>
          {monthlyReport.length > 0 && (
            <div>
              <button onClick={handleGenerateMonthlyCSV}>
                Download Monthly CSV
              </button>
            </div>
          )}
        </div>
      )}
      <div className="generate-buttons">
        <label>Select Date:</label>
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
        />
        <button className="generate-button" onClick={generateDailyReport}>
          Generate Daily Report
        </button>
      </div>
      <div>
        {dailyReport.length > 0 && (
          <div>
            <button onClick={handleGenerateDailyCSV}>Download Daily CSV</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReportGenerator;
