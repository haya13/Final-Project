/*src/AdminComponents/ProductsTable-Dashboard/ProductTable-Dashboard.js*/

import React, { useState, useEffect } from "react";
import axios from "axios";
import ProductTable from "./ProductTable";
import "./ProductTable-Dashboard.css";

const ProductTableDashboard = () => {
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [priceFilter, setPriceFilter] = useState("");
  const [sortBy, setSortBy] = useState("");

  useEffect(() => {
    // Fetch products from the server using axios
    axios
      .get("/api/products") // Update with your API endpoint
      .then((response) => {
        setProducts(response.data.products);
      })
      .catch((error) => {
        console.error("Error fetching products:", error);
      });
  }, []);

  // Implement search, filters, and sort functionality here

  return (
    <div className="admin-product-table">
      <h2>Product Table Dashboard</h2>
      {/* Render the ProductTable component with props */}
      <ProductTable
        products={products}
        searchTerm={searchTerm}
        categoryFilter={categoryFilter}
        priceFilter={priceFilter}
        sortBy={sortBy}
      />
    </div>
  );
};

export default ProductTableDashboard;
