// src/AdminComponents/AdminProductTable/ProductTable.js

import React from "react";

const ProductTable = ({
  products,
  searchTerm,
  categoryFilter,
  priceFilter,
  sortBy,
}) => {
  // Apply search, category filter, price filter, and sorting logic
  let filteredProducts = [...products];

  // Apply search filter
  if (searchTerm) {
    const searchTermLC = searchTerm.toLowerCase();
    filteredProducts = filteredProducts.filter(
      (product) =>
        product.Product_Name.toLowerCase().includes(searchTermLC) ||
        product.Category.toLowerCase().includes(searchTermLC)
    );
  }

  // Apply category filter
  if (categoryFilter) {
    filteredProducts = filteredProducts.filter(
      (product) => product.Category === categoryFilter
    );
  }

  // Apply price filter
  if (priceFilter) {
    const priceFilterValue = parseInt(priceFilter, 10);
    filteredProducts = filteredProducts.filter(
      (product) => parseFloat(product.Product_Price) <= priceFilterValue
    );
  }

  // Apply sorting
  if (sortBy === "priceAsc") {
    filteredProducts.sort(
      (a, b) => parseFloat(a.Product_Price) - parseFloat(b.Product_Price)
    );
  } else if (sortBy === "priceDesc") {
    filteredProducts.sort(
      (a, b) => parseFloat(b.Product_Price) - parseFloat(a.Product_Price)
    );
  }

  return (
    <div className="product-table">
      <table>
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Category</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {filteredProducts.map((product) => (
            <tr key={product.id}>
              <td>{product.Product_Name}</td>
              <td>{product.Category}</td>
              <td>${product.Product_Price}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProductTable;
