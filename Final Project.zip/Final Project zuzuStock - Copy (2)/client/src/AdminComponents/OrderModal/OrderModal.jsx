import { Modal } from "../../components/modal/modal";

export const OrderModal = ({ order, setOrder, products }) => {
  return order ? (
    <Modal
      header={"Order details"}
      content={
        <div>
          {order.items.map((item) => {
            console.log("!!item", item);
            const product = products.find((p) => p.id === item.item_id);
            console.log("!!product", product);
            return (
              <div className="item-row">
                <img src={product.Image_URL} alt="" />
                <p> </p>
                <p>{item.item_id} </p>
                <p>| Amount:{item.quantity}</p>
                <p> | Price: {item.item_Price}</p>
              </div>
            );
          })}
          <p>Final Price: {order.Final_Price}</p>{" "}
          {/* Display the Final Price */}
        </div>
      }
      setOpen={setOrder}
    ></Modal>
  ) : null;
};
