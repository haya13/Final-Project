/*client\src\AdminComponents\Circular-elements\Counter.jsx */
import React from "react";
const Counter = ({
  totalSales,
  totalOrders,
  totalCustomers,
  totalProducts,
}) => {
  console.log(
    "Counter Props:",
    totalSales,
    totalOrders,
    totalCustomers,
    totalProducts
  );

  return (
    <div className="circular-elements">
      <div className="circular-element">
        <div className="circular-content">
          <h3>Total Sales</h3>
          <p>${totalSales}</p>
        </div>
      </div>
      <div className="circular-element">
        <div className="circular-content">
          <h3>Total Orders</h3>
          <p>{totalOrders}</p>
        </div>
      </div>
      <div className="circular-element">
        <div className="circular-content">
          <h3>Total Products</h3>
          <p>{totalProducts}</p>
        </div>
      </div>
      <div className="circular-element">
        <div className="circular-content">
          <h3>Total Customers</h3>
          <p>{totalCustomers}</p>
        </div>
      </div>
    </div>
  );
};

export default Counter;
