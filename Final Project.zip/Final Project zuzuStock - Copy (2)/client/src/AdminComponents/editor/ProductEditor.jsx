/**client/src/AdminComponents/editor/ProductEditor.jsx*/
import React, { useEffect, useState } from "react";
import axios from "axios";
import "./productEditor.css";
import { Link, useParams } from "react-router-dom";
import { ProductList } from "../dataGrid/ProductList";

const ProductEditor = ({ products, fetchProducts }) => {
  const [productId, setProductId] = useState("");
  const [productName, setProductName] = useState("");
  const [productPrice, setProductPrice] = useState("");
  const [productDescription, setProductDescription] = useState("");
  const [color, setColor] = useState("red");
  const [imageUrl, setImageUrl] = useState("");
  const [stock, setStock] = useState(0);
  const { id } = useParams();

  const [categories, setCategories] = useState([]);
  const [category, setCategory] = useState("");
  const [editedProduct, setEditedProduct] = useState();
  const [discountValue, setDiscountValue] = useState(0.0); // Added discount value state
  const [discountedPrice, setDiscountedPrice] = useState(productPrice); // Added state for discounted price

  useEffect(() => {
    if (id) {
      const product = products.find((product) => product.id === id);
      console.log("product", product);
      setEditedProduct(product);
    }
  }, [id]);

  useEffect(() => {
    if (editedProduct) {
      setProductId(editedProduct.id);
      setProductName(editedProduct.Product_Name);
      setProductPrice(editedProduct.Product_Price);
      setProductDescription(editedProduct.Product_Description);
      setColor(editedProduct.Product_Color);
      setStock(editedProduct.Product_Amount);
      setCategory(editedProduct.Category);
      setImageUrl(editedProduct.Image_URL || "");
      setDiscountValue(editedProduct.isOnSale ? 0.1 : 0.0);
      setDiscountedPrice(
        editedProduct.Product_Price * (1 - (editedProduct.isOnSale ? 0.1 : 0.0))
      );
    }
  }, [editedProduct]);

  useEffect(() => {
    // Fetch categories data from the server using axios
    axios
      .get("/api/categories") // Use relative URL
      .then((res) => {
        setCategories(res.data.categories);
        setCategory(res.data.categories[0].Category_Name);
      })
      .catch((err) => console.log(err));
  }, []);

  useEffect(() => {
    // Calculate the discounted price based on the product price and selected discount value
    const discounted = parseFloat(productPrice) * (1 - discountValue);
    setDiscountedPrice(discounted.toFixed(2)); // Update the discounted price state
  }, [productPrice, discountValue]);
  const handleProductSubmit = (e) => {
    e.preventDefault();

    const newProduct = {
      id: productId,
      name: productName,
      // price: productPrice,
      price: discountedPrice, // Use the discounted price

      description: productDescription,
      color: color,
      stock: stock,
      category: category,
      imageUrl: imageUrl,
      isOnSale: discountValue > 0 ? 1 : 0,
    };

    if (editedProduct) {
      axios
        .put("/api/products", newProduct)
        .then((res) => {
          console.log("res", res.data);
          fetchProducts();
          // Handle successful response or update UI
          setEditedProduct();
          setProductId("");
          setProductName("");
          setProductPrice("");
          setProductDescription("");
          setColor("");
          setStock(0);
          setCategory("");
          setImageUrl("");
          setDiscountedPrice(""); // Reset the discounted price
        })
        .catch((error) => {
          // Handle error or show error message
        });
    } else {
      // Send the new product data to the server for updating
      axios
        .post("/api/products", newProduct)
        .then((res) => {
          console.log("res", res.data);
          fetchProducts();
          // Handle successful response or update UI
          setDiscountedPrice(""); // Reset the discounted price
        })
        .catch((error) => {
          console.error(error);
        });
    }
  };

  return (
    <div id="productEditor" className="product-editor-container">
      {/* Navbar */}
      <div className="navbar">
        <Link to="/admin/dashboard" className="nav-link">
          Dashboard
        </Link>
        <Link to="/admin/Orders" className="nav-link">
          Orders
        </Link>
        <Link to="/admin/Products" className="nav-link">
          Products
        </Link>
        <Link to="/admin/dataGrid" className="nav-link">
          Customers
        </Link>
      </div>
      <h2 className="product-editor-title">
        {editedProduct ? "Edit" : "Add"} Product
      </h2>
      <form onSubmit={handleProductSubmit}>
        <div className="formField">
          <label className="product-editor-label">Product ID</label>
          <input
            type="text"
            value={productId}
            onChange={(e) => setProductId(e.target.value)}
            className="product-editor-input"
            disabled={editedProduct}
            readOnly={editedProduct}
          />
        </div>
        <div className="formField">
          <label className="product-editor-label">Product Name</label>
          <input
            type="text"
            value={productName}
            onChange={(e) => setProductName(e.target.value)}
            className="product-editor-input"
          />
        </div>
        {editedProduct && ( // Conditionally render the "Discount Value" dropdown for editing
          <div className="formField">
            <label className="product-editor-label">Discount Value</label>
            <select
              value={discountValue}
              onChange={(e) => setDiscountValue(parseFloat(e.target.value))}
            >
              <option value="0.0">Select</option>
              <option value="0.1">10%</option>
              <option value="0.2">20%</option>
              <option value="0.3">30%</option>
              <option value="0.4">40%</option>
              <option value="0.5">50%</option>
              <option value="0.6">60%</option>
              <option value="0.7">70%</option>
              <option value="0.8">80%</option>
            </select>
          </div>
        )}
        <div className="formField">
          <label className="product-editor-label">Product Price</label>
          <input
            type="text"
            value={productPrice}
            onChange={(e) => setProductPrice(e.target.value)}
            className="product-editor-input"
          />
        </div>
        <div className="formField">
          <label className="product-editor-label">Image Url</label>
          <input
            type="text"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            className="product-editor-input"
          />
        </div>
        <div className="formField">
          <label className="product-editor-label">Stock Amount</label>
          <input
            type="number"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            className="product-editor-input"
          />
        </div>
        <div className="formField">
          <label className="product-editor-label" for="color">
            Color
          </label>
          <select
            id="color"
            value={color}
            onChange={(e) => setColor(e.target.value)}
          >
            <option value="White">White</option>
            <option value="Black">Black</option>
            <option value="Brown">Brown</option>
            <option value="Red">Red</option>
            <option value="Blue">Blue</option>
            <option value="Green">Green</option>
            <option value="Yellow">Yellow</option>
            <option value="Orange">Orange</option>
            <option value="Purple">Purple</option>
            <option value="Pink">Pink</option>
            <option value="Gray">Gray</option>
            <option value="Gold">Gold</option>
            <option value="Silver">Silver</option>
            <option value="Cyan">Cyan</option>
            <option value="Magenta">Magenta</option>
            <option value="Lime">Lime</option>
            <option value="Teal">Teal</option>
            <option value="Indigo">Indigo</option>
            <option value="Aqua">Aqua</option>
            <option value="Maroon">Maroon</option>
            <option value="Navy">Navy</option>
          </select>
        </div>
        <div className="formField">
          <label className="product-editor-label" for="category">
            Category
          </label>
          <select
            id="category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            {categories.map((category) => (
              <option value={category.Category_Name}>
                {category.Category_Name}
              </option>
            ))}
          </select>
        </div>
        <div className="formField">
          <label className="product-editor-label">Product Description</label>

          <textarea
            value={productDescription}
            onChange={(e) => setProductDescription(e.target.value)}
            className="product-editor-textarea"
          />
        </div>
        <button type="submit" className="product-editor-button">
          Save Product
        </button>
      </form>

      {/* Product List Section */}
      <div className="product-list-section">
        <ProductList
          setEditedProduct={setEditedProduct}
          products={products}
          fetchProducts={fetchProducts}
        />
      </div>
    </div>
  );
};

export default ProductEditor;
