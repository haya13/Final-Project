// src/AdminComponents/editor/CategoryEditor.js
import React from "react";
import "./categoryEditor.css"
import "./productEditor.css";
const CategoryEditor = () => {
  // Implement category editing functionality here
  return <div>{/* Category editing form */}</div>;
};

export default CategoryEditor;
