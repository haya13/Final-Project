import React, { useState, useEffect } from "react";
import axios from "axios";
import "./salesTarget.css";

const SalesTarget = () => {
  const [monthlyTarget, setMonthlyTarget] = useState(0);
  const [dailyTarget, setDailyTarget] = useState(0);
  const [currentMonthRevenue, setCurrentMonthRevenue] = useState(0);
  const [currentDayRevenue, setCurrentDayRevenue] = useState(0);
  const [current_Date, setCurrentDate] = useState("");
  const [monthlyTargetReached, setMonthlyTargetReached] = useState(false);
  const [dailyTargetReached, setDailyTargetReached] = useState(false);

  useEffect(() => {
    // Retrieve targets from localStorage on component mount
    const storedMonthlyTarget = localStorage.getItem("monthlyTarget");
    const storedDailyTarget = localStorage.getItem("dailyTarget");

    if (storedMonthlyTarget !== null) {
      setMonthlyTarget(Number(storedMonthlyTarget));
    }

    if (storedDailyTarget !== null) {
      setDailyTarget(Number(storedDailyTarget));
    }

    // Get the current date in the format "yy/mm/dd"
    const formattedDate = new Date().toISOString().substring(0, 10);
    setCurrentDate(formattedDate);

    // Calculate current month and day revenue
    calculateRevenues(formattedDate);
  }, []);

  useEffect(() => {
    // Check if the monthly target has been reached
    if (currentMonthRevenue >= monthlyTarget) {
      setMonthlyTargetReached(true);
    } else {
      setMonthlyTargetReached(false);
    }

    // Check if the daily target has been reached
    if (currentDayRevenue >= dailyTarget) {
      setDailyTargetReached(true);
    } else {
      setDailyTargetReached(false);
    }
  }, [currentMonthRevenue, currentDayRevenue, monthlyTarget, dailyTarget]);

  const calculateRevenues = (selectedDate) => {
    axios
      .get("/api/orders")
      .then((res) => {
        const orders = res.data;

        const currentDate = new Date();
        const currentMonth = currentDate.getMonth() + 1; // Month is zero-indexed
        const currentYear = currentDate.getFullYear();

        const currentMonthOrders = orders.filter((order) => {
          const orderDate = new Date(order.Order_Date);
          return (
            orderDate.getMonth() + 1 === currentMonth &&
            orderDate.getFullYear() === currentYear
          );
        });

        const currentDayOrders = orders.filter((order) => {
          const orderDate = new Date(order.Order_Date)
            .toISOString()
            .substring(0, 10);
          return orderDate === selectedDate;
        });

        const totalMonthRevenue = currentMonthOrders.reduce(
          (total, order) => total + parseFloat(order.Final_Price),
          0
        );

        const totalDayRevenue = currentDayOrders.reduce(
          (total, order) => total + parseFloat(order.Final_Price),
          0
        );

        setCurrentMonthRevenue(totalMonthRevenue.toFixed(2));
        setCurrentDayRevenue(totalDayRevenue.toFixed(2));
      })
      .catch((err) => {
        console.log("Error fetching revenue:", err);
      });
  };

  const handleMonthlyTargetChange = (e) => {
    const newMonthlyTarget = parseFloat(e.target.value);
    setMonthlyTarget(newMonthlyTarget);
    localStorage.setItem("monthlyTarget", newMonthlyTarget);
  };

  const handleDailyTargetChange = (e) => {
    const newDailyTarget = parseFloat(e.target.value);
    setDailyTarget(newDailyTarget);
    localStorage.setItem("dailyTarget", newDailyTarget);
  };

  return (
    <div className="sales-target">
      <h2>Sales Targets and Revenues</h2>

      <div className="target-inputs">
        <div className="target-input">
          <label htmlFor="monthlyTarget">Monthly Sales Target:</label>
          <input
            type="number"
            id="monthlyTarget"
            value={monthlyTarget}
            onChange={handleMonthlyTargetChange}
          />
        </div>
        <div className="target-input">
          <label htmlFor="dailyTarget">Daily Sales Target:</label>
          <input
            type="number"
            id="dailyTarget"
            value={dailyTarget}
            onChange={handleDailyTargetChange}
          />
        </div>
      </div>

      <div className="revenues">
        <div className="revenue">
          <p>Current Month Revenue ({current_Date.substring(0, 7)}):</p>
          <p
            style={{
              color: monthlyTargetReached ? "green" : "inherit",
              fontWeight: monthlyTargetReached ? "bold" : "normal",
            }}
          >
            ${currentMonthRevenue}
          </p>
          {monthlyTargetReached && (
            <p className="target-reached">Monthly Target Reached</p>
          )}
        </div>
        <div className="revenue">
          <p>{current_Date} Revenue:</p>
          <p
            style={{
              color: dailyTargetReached ? "green" : "inherit",
              fontWeight: dailyTargetReached ? "bold" : "normal",
            }}
          >
            ${currentDayRevenue}
          </p>
          {dailyTargetReached && (
            <p
              className="target-reached"
              style={{
                color: monthlyTargetReached ? "green" : "inherit",
                fontWeight: monthlyTargetReached ? "bold" : "normal",
              }}
            >
              Daily Target Reached
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default SalesTarget;
