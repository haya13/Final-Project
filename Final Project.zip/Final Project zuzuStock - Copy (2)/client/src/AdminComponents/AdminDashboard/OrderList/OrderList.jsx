// Import necessary modules and CSS
import axios from "axios";
import React, { useEffect, useState } from "react";
import "./OrderList.css";
import { Link } from "react-router-dom";
import { OrderModal } from "../../OrderModal/OrderModal";
import { checkIsAdmin } from "../../../utilities/isAdmin";

// Define the OrderList component
export const OrderList = ({ products }) => {
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [orders, setOrders] = useState([]);
  // State for selected order IDs to archive
  const [selectedOrderIds, setSelectedOrderIds] = useState([]);
  // State for date range filtering
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const isAdmin = checkIsAdmin();

  // State for archived order IDs
  const [archivedOrderIds, setArchivedOrderIds] = useState(
    JSON.parse(sessionStorage.getItem("archivedOrderIds")) || []
  );

  // Handler for toggling selected orders
  const toggleSelectOrder = (orderId) => {
    setSelectedOrderIds((prevSelectedOrderIds) =>
      prevSelectedOrderIds.includes(orderId)
        ? prevSelectedOrderIds.filter((id) => id !== orderId)
        : [...prevSelectedOrderIds, orderId]
    );
  };

  // Handle archiving selected orders
  const handleArchiveSelectedOrders = () => {
    // Update archivedOrderIds
    const updatedArchivedOrderIds = [...archivedOrderIds, ...selectedOrderIds];
    setArchivedOrderIds(updatedArchivedOrderIds);
    sessionStorage.setItem(
      "archivedOrderIds",
      JSON.stringify(updatedArchivedOrderIds)
    );

    // Remove selected orders from the orders list
    const updatedOrders = orders.filter(
      (order) => !selectedOrderIds.includes(order.id)
    );
    setOrders(updatedOrders);

    // Clear the selected order IDs
    setSelectedOrderIds([]);
  };

  // Handlers for date range filtering
  const handleStartDateChange = (event) => {
    setStartDate(new Date(event.target.value));
  };

  const handleEndDateChange = (event) => {
    setEndDate(new Date(event.target.value));
  };

  // Handle changing order status to "Delivered"
  const handleDeliverOrder = async (orderId) => {
    try {
      // Simulate a loading state
      const loadingTime = 2000; // 2 seconds
      setOrders((prevOrders) =>
        prevOrders.map((order) =>
          order.id === orderId ? { ...order, delivering: true } : order
        )
      );

      // Simulate a delay for loading message
      await new Promise((resolve) => setTimeout(resolve, loadingTime));

      // Update the order status and set delivering to false
      const updatedOrders = orders.map((order) =>
        order.id === orderId
          ? { ...order, delivering: false, status: "Delivered" }
          : order
      );
      setOrders(updatedOrders);

      // Store the updated orders in localStorage
      localStorage.setItem("orders", JSON.stringify(updatedOrders));
    } catch (err) {
      console.log(err);
    }
  };

  // Function to fetch orders with date range filtering
  const fetchOrdersWithDateRange = () => {
    const queryParams = `?startDate=${startDate.toISOString()}&endDate=${endDate.toISOString()}`;
    axios
      .get(`/api/orders${queryParams}`)
      .then((res) => {
        setOrders(res.data);
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    fetchOrdersWithDateRange();
  }, []);

  useEffect(() => {
    fetchOrdersWithDateRange();
  }, [startDate, endDate]);

  // Function to fetch all orders
  const fetchOrders = () => {
    axios
      .get("/api/orders")
      .then((res) => {
        setOrders(res.data);
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  // Handle order deletion
  const handleDeleteOrder = async (orderId) => {
    try {
      await axios.delete(`/api/orders/${orderId}`);
      fetchOrders(); // Refresh the orders after deletion
    } catch (err) {
      console.log(err);
    }
  };

  /********************************* */
  const [deliverySuccess, setDeliverySuccess] = useState(false);

  // Handle changing order status
  const handleStatusChange = async (orderId, newStatus) => {
    try {
      if (newStatus === "Delivered") {
        // Simulate a loading state
        setOrders((prevOrders) =>
          prevOrders.map((order) =>
            order.id === orderId ? { ...order, delivering: true } : order
          )
        );

        const updatedOrders = orders.map((order) =>
          order.id === orderId
            ? { ...order, delivering: false, status: newStatus }
            : order
        );
        setOrders(updatedOrders);

        // Set deliverySuccess to true
        setDeliverySuccess(true);

        // Store the updated orders in localStorage
        localStorage.setItem("orders", JSON.stringify(updatedOrders));
      } else {
        // Update other status without delay
        const updatedOrders = orders.map((order) =>
          order.id === orderId ? { ...order, status: newStatus } : order
        );
        setOrders(updatedOrders);
        localStorage.setItem("orders", JSON.stringify(updatedOrders));
      }
    } catch (err) {
      console.log(err);
    }
  };
  /************************* */

  // Render the OrderList component
  return (
    <>
      <div id="orderList" className="data-grid-feature">
        <h2>Latest Orders</h2>

        {/* Filter by date section */}
        <div className="filter-by-date">
          <label>From : </label>
          <input
            type="date"
            value={startDate.toISOString().substr(0, 10)}
            onChange={handleStartDateChange}
          />
          <label>To : </label>
          <input
            type="date"
            value={endDate.toISOString().substr(0, 10)}
            onChange={handleEndDateChange}
          />
          <button onClick={fetchOrdersWithDateRange}>Apply Filter</button>
        </div>

        {/* Product list */}
        <div className="product-list">
          <table>
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Date</th>
                <th>Shipping Address</th>
                <th>Cancel Order</th>
                <th>Status</th>
                <th>Select</th>
              </tr>
            </thead>
            <tbody>
              {orders
                .filter((order) => !archivedOrderIds.includes(order.id))
                .sort((a, b) => new Date(b.Order_Date) - new Date(a.Order_Date)) // Sort by order date in descending order
                .map((order) => (
                  <tr key={order.id}>
                    <td>
                      <Link onClick={() => setSelectedOrder(order)}>
                        {order.id}
                      </Link>
                    </td>
                    <td>{new Date(order.Order_Date).toLocaleDateString()}</td>
                    <td>{order.Destination_Address}</td>
                    <td>
                      <button onClick={() => handleDeleteOrder(order.id)}>
                        Cancel
                      </button>
                    </td>
                    <td>
                      {order.delivering ? (
                        <div className="loading-message">Pending...</div>
                      ) : (
                        <>
                          {selectedOrderIds.includes(order.id) ? (
                            <span className="check-icon">&#10003;</span>
                          ) : order.status === "Pending" ? (
                            <span className="status-pending">Pending</span>
                          ) : (
                            <span className="status-delivered">Pending</span>
                          )}
                        </>
                      )}
                    </td>
                    <td>
                      <input
                        type="checkbox"
                        checked={selectedOrderIds.includes(order.id)}
                        onChange={() => toggleSelectOrder(order.id)}
                      />
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
          <button
            onClick={handleArchiveSelectedOrders}
            disabled={selectedOrderIds.length === 0}
          >
            Archive Selected
          </button>
        </div>
      </div>
      <OrderModal
        order={selectedOrder}
        setOrder={setSelectedOrder}
        products={products}
      />
    </>
  );
};

export const orders = OrderList;
