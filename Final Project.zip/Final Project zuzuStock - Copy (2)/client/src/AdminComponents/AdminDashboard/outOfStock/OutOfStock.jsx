/**client\src\AdminComponents\AdminDashboard\outOfStock\OutOfStock.jsx */
import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import "./outOfStock.css";

const OutOfStock = () => {
  const [outOfStockProducts, setOutOfStockProducts] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [lowProducts, setLowProducts] = useState([]);

  useEffect(() => {
    // Fetch products
    axios
      .get("/api/products") // Use the appropriate API endpoint
      .then((response) => {
        const products = response.data.products;

        // Filter products with Product_Amount = 0 (out of stock)
        const outOfStock = products.filter(
          (product) => parseFloat(product.Product_Amount) === 0
        );
        // Filter products with Product_Amount between 0 and 5 (inclusive)
        const lowInStock = products.filter(
          (product) =>
            parseFloat(product.Product_Amount) > 0 &&
            parseFloat(product.Product_Amount) <= 5
        );
        setLowProducts(lowInStock);

        setOutOfStockProducts(outOfStock);
      })
      .catch((error) => {
        console.error("Error fetching out of stock products:", error);
      });
  }, []);
  // Handler for search input change
  const handleSearchChange = (event) => {
    setSearchText(event.target.value);
  };
  // Filter products based on search text
  const filteredProducts = outOfStockProducts.filter(
    (product) =>
      product.id.toLowerCase().includes(searchText.toLowerCase()) ||
      product.Product_Name.toLowerCase().includes(searchText.toLowerCase())
  );
  // Filter products based on search text
  const filteredLowProducts = lowProducts.filter(
    (product) =>
      product.id.toLowerCase().includes(searchText.toLowerCase()) ||
      product.Product_Name.toLowerCase().includes(searchText.toLowerCase())
  );
  return (
    <div className="out-of-stock">
      <h2>Out of Stock Products</h2>
      <div className="search-container">
        <input
          type="text"
          placeholder="Search"
          value={searchText}
          onChange={handleSearchChange}
        />
      </div>
      <table>
        <thead>
          <tr>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredProducts.map((product) => (
            <tr key={product.id}>
              <td>{product.id}</td>
              <td>{product.Product_Name}</td>
              <td>
                <Link to={`/admin/Products/edit/${product.id}`}>
                  View Details
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <h2>Low on Stock Products </h2>

      <table>
        <thead>
          <tr>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredLowProducts.map((product) => (
            <tr key={product.id}>
              <td>{product.id}</td>
              <td>{product.Product_Name}</td>
              <td>{product.Product_Amount}</td>
              <td>
                <Link to={`/admin/Products/edit/${product.id}`}>
                  View Details
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OutOfStock;
