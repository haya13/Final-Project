// /** client/src/AdminCompnents/AdminDashboard/AdminDashboard.jsx */
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { OrderList } from "./OrderList/OrderList";
import { BarChart } from "../dataGrid/bar-chart";
import CityTable from "../dataGrid/CityTable";
import "./adminDashboard.css";
import axios from "axios";
import Counter from "../Circular-elements/Counter";
import OutOfStock from "./outOfStock/OutOfStock";
import SalesTarget from "./salesTarget/SalesTarget";
import "react-calendar/dist/Calendar.css";

const AdminDashboard = ({ products, users }) => {
  const [totalSales, setTotalSales] = useState(0);
  const [totalOrders, setTotalOrders] = useState(0);
  const [vatValue, setVatValue] = useState(
    parseFloat(sessionStorage.getItem("vatValue")) || 17
  );

  const handleVatChange = (event) => {
    const newVatValue = parseFloat(event.target.value);
    setVatValue(newVatValue);
    sessionStorage.setItem("vatValue", newVatValue.toString());
  };
  useEffect(() => {
    // Fetch total sales
    axios
      .get("/api/orders")
      .then((response) => {
        const orders = response.data;
        console.log("orders", orders);

        let totalSales = 0;
        for (const order of orders) {
          totalSales += Number(order.Final_Price);
        }
        // Round the total sales to 2 decimal places
        totalSales = totalSales.toFixed(2);
        setTotalSales(totalSales);
        setTotalOrders(orders.length);
      })
      .catch((error) => {
        console.error("Error fetching total sales:", error);
      });
  }, []);

  const [orders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [selectedDate] = useState(new Date());

  useEffect(() => {
    // Filter orders based on the selected date
    const filtered = orders.filter((order) => {
      const orderDate = new Date(order.Order_Date);
      return (
        orderDate.getDate() === selectedDate.getDate() &&
        orderDate.getMonth() === selectedDate.getMonth() &&
        orderDate.getFullYear() === selectedDate.getFullYear()
      );
    });
    setFilteredOrders(filtered);
  }, [orders, selectedDate]);

  return (
    <div className="admin-dashboard">
      {/* Navbar */}
      <div className="navbar">
        <Link to="/admin/dashboard" className="nav-link">
          Dashboard
        </Link>
        <Link to="/admin/Orders" className="nav-link">
          Orders
        </Link>
        <Link to="/admin/Products" className="nav-link">
          Products
        </Link>
        <Link to="/admin/dataGrid" className="nav-link">
          Customers
        </Link>
      </div>
      <div>
        <Counter
          totalSales={totalSales}
          totalOrders={totalOrders}
          totalCustomers={users.length}
          totalProducts={products.length}
        />
      </div>
      {/* Summary Boxes */}
      <div className="summary-boxes">{/* ... Summary box components */}</div>
      {/* Charts */}
      <div className="chart-container">
        <div className="chart">
          <h2>Most purchased items</h2>
          <BarChart />
        </div>
        <div className="chart">
          <h2>Reached Customers</h2>
          <CityTable />
        </div>
      </div>

      {/* Latest Orders and Out of Stock Products */}
      <div className="data-tables">
        <div className="latest-orders">
          <OrderList orders={filteredOrders} products={products} />
        </div>

        <div className="out-of-stock-container">
          <OutOfStock />
          <SalesTarget />
          {/* VAT Input Field */}
          <div class="vat-input-container">
            <table className="vat-input-table">
              <tbody>
                <tr>
                  <td className="vat-label" colspan="2">
                    <label htmlFor="vatValue">VAT Value:</label>
                  </td>
                </tr>
                <tr>
                  <td className="vat-input-cell">
                    <input
                      type="number"
                      id="vatValue"
                      value={vatValue}
                      onChange={handleVatChange}
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
