/* src/AdminComponents/charts/Chart.js */
import React, { useEffect } from "react";

// import { Bar } from "react-chartjs-2";
import "./chart.css";

const Chart = ({ cityData }) => {
  const data = {
    labels: cityData.map((city) => city.City),
    datasets: [
      {
        label: "Number of Customers",
        data: cityData.map((city) => city.count),
        backgroundColor: "rgba(75, 192, 192, 0.2)",
        borderColor: "rgba(75, 192, 192, 1)",
        borderWidth: 1,
      },
    ],
  };

  const options = {
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };
  // Use useEffect to destroy previous chart before rendering a new one
  useEffect(() => {
    const chartInstance = new Chart(document.getElementById("myChart"), {
      type: "bar",
      data,
      options,
    });

    // Cleanup function to destroy the chart
    return () => {
      chartInstance.destroy();
    };
  });

  return (
    <div className="chart-container">
      <canvas id="myChart" width="800" height="400"></canvas>
    </div>
  );
};
export default Chart;
