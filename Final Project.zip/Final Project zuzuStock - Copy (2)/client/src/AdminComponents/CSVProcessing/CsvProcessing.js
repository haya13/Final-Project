/*client\src\AdminComponents\CSVProcessing\CsvProcessing.js */
import React from "react";
import { saveAs } from "file-saver"; // Import the file-saver library

const CsvProcessing = ({ data, fileName, buttonText = "Generate CSV" }) => {
  console.log("data", data);
  const generateCSV = () => {
    // Create the CSV content
    const csvContent =
      Object.keys(data[0]).join(",") +
      "\n" +
      data.map((item) => Object.values(item).join(",")).join("\n");

    // Create a Blob object from the CSV content
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8" });

    // Use the file-saver library to initiate the download
    saveAs(blob, fileName);
  };

  const handleGenerateCSV = () => {
    generateCSV();
  };

  return (
    <div className="csv-processing">
      <button onClick={handleGenerateCSV}>{buttonText} </button>
    </div>
  );
};

export default CsvProcessing;
