/*src/AdminComponents/registeredUsersList/RegisteredUsersList.js */
import React, { useState } from "react";
import "./registeredUsersList.css";
import CsvGenerator from "../../AdminComponents/CSVProcessing/CsvProcessing";

import { Link } from "react-router-dom";
const RegisteredUsersList = ({ users }) => {
  const [filterOption, setFilterOption] = useState("");
  const [filterValue, setFilterValue] = useState("");

  //csvHeaders for tables
  const csvHeaders = [
    { label: "First Name", key: "First_Name" },
    { label: "Last Name", key: "Last_Name" },
    { label: "City", key: "City" },
    { label: "Street", key: "Street" },
    { label: "Zip", key: "Zip" },
    { label: "Email", key: "Email" },
    { label: "User Status", key: "user_status" },
  ];

  const handleFilterOptionChange = (event) => {
    setFilterOption(event.target.value);
    setFilterValue(""); // Clear the filter value when changing the filter option
  };

  const handleFilterValueChange = (event) => {
    setFilterValue(event.target.value);
  };

  //filtered Users
  const filteredUsers = users.filter((user) => {
    if (!filterOption) return true;
    return user[filterOption].toLowerCase().includes(filterValue.toLowerCase());
  });

  return (
    <div className="registered-users-list">
      {/* Include the navbar */}
      <div className="navbar">
        <Link to="/admin/dashboard" className="nav-link">
          Dashboard
        </Link>
        <Link to="/admin/Orders" className="nav-link">
          Orders
        </Link>
        <Link to="/admin/Products" className="nav-link">
          Products
        </Link>
        <Link to="/admin/dataGrid" className="nav-link">
          Customers
        </Link>
      </div>
      <h2>Registered Users and Orders</h2>
      {/* Filter container */}
      <div className="filter-container">
        <span>Filter By:</span>
        <select value={filterOption} onChange={handleFilterOptionChange}>
          <option value="">None</option>
          <option value="First_Name">First Name</option>
          <option value="Last_Name">Last Name</option>
          <option value="City">City</option>
          <option value="Street">Street</option>
          <option value="Email">Email</option>
        </select>
        {filterOption && (
          <input
            type="text"
            placeholder={`Filter by ${filterOption}`}
            value={filterValue}
            onChange={handleFilterValueChange}
          />
        )}
      </div>
      <div className="users-and-orders-container">
        <div className="users-table-container">
          <h3>Registered Users</h3>
          <table className="users-table">
            <thead>
              <tr>
                {/* <th>id</th> */}
                <th>First Name</th>
                <th>Last Name</th>
                <th>City</th>
                <th>Street</th>
                <th>Zip</th>
                <th>Email</th>
                <th>User Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => (
                <tr
                  key={user.id}
                  className={user.user_status === 0 ? "inactive-user" : ""}
                >
                  {/* <td>{user.id}</td> */}
                  <td>{user.First_Name}</td>
                  <td>{user.Last_Name}</td>
                  <td>{user.City}</td>
                  <td>{user.Street}</td>
                  <td>{user.Zip}</td>
                  <td>
                    <Link to={`/user/orders/${user.Email}`}>{user.Email}</Link>
                  </td>
                  <td>{user.user_status === 0 ? "Admin" : "Customer"}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="csv-button-container">
            <CsvGenerator
              data={filteredUsers}
              fileName="registered_users.csv"
              headers={csvHeaders}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisteredUsersList;
