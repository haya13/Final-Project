// src/components/calendar/MiniCalendar.js
import React, { useState } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import "./miniCalendar.css"; // Make sure to add the correct path to your CSS file

const MiniCalendar = () => {
  const [value, onChange] = useState(new Date());

  return (
    <div className="mini-calendar">
      <Calendar onChange={onChange} value={value} view="month" />
    </div>
  );
};

export default MiniCalendar;
