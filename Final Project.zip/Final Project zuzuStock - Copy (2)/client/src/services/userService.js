/**client/src/services/userService.js */
import axios from "axios";

// API endpoint for users
const api = "/api/users";

/**
 * Performs a GET request to fetch details of a specific user based on the user ID.
 * @param {string} user_id - The user ID.
 * @returns {Promise} - Returns a promise that resolves with the server response.
 */
export function getUser(user_id) {
  return axios.get(`${api}/${user_id}`);
}

/**
 * Performs a POST request to register a new user.
 * @param {Object} user - User details described in an object.
 * @returns {Promise} - Returns a promise that resolves with the server response.
 */
export function registerUser(user) {
  return axios.post(`${api}`, user);
}

/**
 * Performs a POST request to log in a user.
 * @param {Object} user - User details described in an object.
 * @returns {Promise} - Returns a promise that resolves with the server response.
 */
export function loginUser(user) {
  return axios
    .post(`${api}/login`, user)
    .then((res) => {
      console.log("Server response:", res.data);

      // Check if the response data contains the user_status field
      const { message, user_status, user } = res.data;
      console.log("Message:", message);
      console.log("User Status:", user_status);
      console.log("User:", user);

      if (
        message === "User logged in successfully" &&
        typeof user_status === "number" &&
        user
      ) {
        return { user_status, user };
      } else {
        throw new Error("Invalid response data");
      }
    })
    .catch((err) => {
      throw err;
    });
}

/**
 * Performs a GET request to fetch all registered users.
 * @returns {Promise} - Returns a promise that resolves with the server response.
 */
export function getAllUsers() {
  return axios.get(`${api}/users`);
}
