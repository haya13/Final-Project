/**client/src/services/categoryService.js */
import axios from "axios";
// API endpoint for categories
const api = "/api/categories";
/**
 * Performs a GET request to fetch categories.
 *
 * @returns {Promise} - A promise that resolves with the server response.
 */
export function getCategories() {
  return axios.get(`${api}`);
}


/**axios library, which is a popular HTTP client used for making API requests. */