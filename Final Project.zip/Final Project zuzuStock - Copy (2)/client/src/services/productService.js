// client/services/productService.js

import axios from "axios";

// API endpoints for products and categories
const api = "/api/products";
const category_api = "/api/categories";

/**
 * Performs a GET request to fetch the list of products.
 * @returns {Promise} - Returns a promise that resolves with the server response.
 */
export function getProducts() {
  return axios.get(api);
}
/**
 * Performs a POST request to add a new product.
 * @param {Object} product - Details of the product described in an object.
 * @returns {Promise} - Returns a promise that resolves with the server response.
 */
export function addProduct(product) {
  return axios.post(api, product);
}

/**
 * Performs a GET request to fetch specific product details based on the product ID.
 * @param {string} id - The product ID.
 * @returns {Promise} - Returns a promise that resolves with the server response.
 */
export function getProduct(id) {
  return axios.get(`${api}/${id}`);
}

/**
 * Performs a GET request to fetch a list of products based on the category name.
 * @param {string} category_name - The category name.
 * @returns {Promise} - Returns a promise that resolves with the server response.
 */
// export function getProductsByCategory(category_name) {
//   return axios.get(`${category_api}/${category_name}`);
// }
export function getProductsByCategory(category_name) {
  return api.get(`/products/${category_name}`);
}
