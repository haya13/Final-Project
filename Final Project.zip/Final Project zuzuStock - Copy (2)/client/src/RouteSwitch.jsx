import React, { useEffect, useState } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import TopBar from "./components/top-bar/TopBar";
import Home from "./components/home/Home";
import About from "./components/about/About";
import Register from "./components/register/Register";
import Login from "./components/login/Login";
import Footer from "./components/footer/Footer";
import AdminDashboard from "./AdminComponents/AdminDashboard/AdminDashboard";
import Shop from "./components/productsgrid/Shop";
import UserProfile from "./components/UserProfile/UserProfile";
import RegisteredUsersList from "./AdminComponents/registeredUsersList/RegisteredUsersList";
import CsvProcessing from "./AdminComponents/CSVProcessing/CsvProcessing";
import ProductEditor from "./AdminComponents/editor/ProductEditor";
import ProductList from "./AdminComponents/dataGrid/ProductList";
import { OrderList } from "./AdminComponents/AdminDashboard/OrderList/OrderList";
import OrderListTable from "./AdminComponents/ordersTable/OrderListTable ";
import axios from "axios";
import { getAllUsers } from "./services/userService";

export default function RouteSwitch({ userStatus }) {
  const [products, setProducts] = useState([]);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    // Fetch products when the component mounts
    fetchProducts();
  }, []);

  useEffect(() => {
    // Fetch all registered users when the component mounts
    getAllUsers()
      .then((res) => {
        setUsers(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  function fetchProducts() {
    // Fetch products from the server
    axios
      .get("/api/products")
      .then((res) => {
        setProducts(res.data.products);
      })
      .catch((err) => console.log(err));
  }

  return (
    <BrowserRouter>
      <TopBar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/shop" element={<Shop />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route
          path="/admin/dashboard"
          element={<AdminDashboard products={products} users={users} />}
        />
        <Route path="/profile" element={<UserProfile />} />
        <Route
          path="/admin/dataGrid"
          element={<RegisteredUsersList users={users} />}
        />
        <Route path="/admin/csv-processing" element={<CsvProcessing />} />

        {/* Create a nested route for /admin/Products */}
        <Route
          path="/admin/Products/*"
          element={
            <ProductEditor products={products} fetchProducts={fetchProducts} />
          }
        >
          <Route path="list" element={<ProductList />} />
        </Route>
        <Route
          path="/admin/Products/edit/:id"
          element={
            <ProductEditor products={products} fetchProducts={fetchProducts} />
          }
        />

        {/* Add the OrderList route */}
        <Route path="/admin/Products/orders" element={<OrderList />} />
        <Route
          path="/admin/Orders"
          element={<OrderListTable products={products} />}
        />
        <Route
          path="/user/orders/:email"
          element={<OrderListTable products={products} />}
        />
      </Routes>
      <Footer />
    </BrowserRouter>
  );
}
