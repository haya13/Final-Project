import React from "react";
import "./index.css";
import RouteSwitch from "./RouteSwitch";
import { createRoot } from "react-dom/client"; 
//import ReactDOM from "react-dom";
import "chart.js"; 

// Create a React root element using ReactDOM.createRoot to render the application
const root = createRoot(document.getElementById("root")); // Updated usage


// Render the RouteSwitch component inside React.StrictMode.
// StrictMode helps to identify potential problems in the application during development.
root.render(
  <React.StrictMode>
    <RouteSwitch/>
  </React.StrictMode>
);
