/*client/src/components/about/About.jsx */
import React from "react";
import "./About.css";
export default function About() {
  // Define latitude and longitude for the store's location
  const ourLatitude = 32.508033;
  const ourLongitude = 35.075372;
  //Location
  // Function to open Google Maps with the store's location
  const openStoreLocation = () => {
    // Generate a Google Maps link based on the latitude and longitude
    const storeLocationLink = `https://www.google.com/maps/place/${ourLatitude},${ourLongitude}`;
    // Open the link in a new browser tab/window
    window.open(storeLocationLink, "_blank");
  };
  return (
    <div className="about-grid">
  
      {/* Section 1: Introduction */}
      <div className="about-section about-intro">
        <div className="square"></div>
        <h2>Welcome to Zuzu Stock</h2>
        <p>
          Your ultimate destination for affordable and diverse home essentials!
          Located in the vibrant city of Shfaraam, our warehouse store offers a
          wide range of products to cater to your everyday needs. Whether you're
          searching for daily use items or looking to complete your home decor,
          we've got you covered with our extensive selection.
        </p>
      </div>
      {/* Section 2: Description */}
      <div className="about-section about-description">
        <div className="square"></div>
        <h3>What you can find Here</h3>
        <p>
          At Zuzu Stock, we take pride in offering top-quality products at
          minimum prices, ensuring that everyone can find what they need without
          breaking the bank. Our store concept is inspired by the idea of
          providing a mini Ikea experience, where you can discover everything
          you require to make your home feel complete. We are committed to
          customer satisfaction and believe that affordable doesn't mean
          compromising on quality. Shop with us and experience convenience,
          affordability, and a delightful shopping experience.
        </p>
      </div>

      <div className="about-section about-contact">
        <div className="square"></div>
        <h3>Contact Us</h3>
        <p>Phone: +972 508810991</p>
        <p>Email: HayaMasoud099@gmail.com</p>
        <p>
          Follow us on social media:{" "}
          <a href="https://www.facebook.com/" target="_blank">
            Facebook
          </a>{" "}
          |{" "}
          <a href="https://www.instagram.com/" target="_blank">
            Instagram
          </a>
          <p>Waiting for your visit !</p>
          <img
            src="/Pictures/location.png"
            alt="Open Store Location"
            className="location-icon"
            onClick={openStoreLocation}
          />
        </p>
      </div>
  
    </div>
  );
}
