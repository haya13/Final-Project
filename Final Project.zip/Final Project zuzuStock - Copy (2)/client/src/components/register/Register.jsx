/*client/src/components/register/Register.jsx */
import React, { useState } from "react";
import "./register.css";
import { Link, useNavigate } from "react-router-dom";
import { registerUser } from "../../services/userService";
import useForm from "../../hooks/useForm";
import formValidate from "../../utilities/formValidate";

// Define the functional component "Register"
export default function Register() {
  const [isRegistered, setIsRegistered] = useState(false);
  const [showPopup, setShowPopup] = useState(false);

  const navigate = useNavigate();
  const [userValue, setUserValue] = useState({
    firstName: "",
    lastName: "",
    street: "",
    city: "",
    zipCode: "",
    email: "",
    password: "",
  });

  // Use the custom "useForm" hook to handle form input and submission
  const myForm = useForm([
    userValue,
    setUserValue,
    {
      onsubmit: async (event) => {
        event.preventDefault();
        // Validate the form inputs using the "formValidate" utility
        const { isValid, errors } = formValidate(userValue);

        if (isValid) {
          try {
            const res = await registerUser(userValue);
            navigate("/login");

            // Set the isRegistered state to true first
            setIsRegistered(true);
          } catch (err) {
            console.log(err);
            alert(err?.response?.data?.error || err.message); // Display error message if registration fails
          }
        } else {
          // Display error messages for invalid fields
          alert(Object.values(errors).join("\n"));
        }
      },
    },
  ]);

  return (
    <div id="register" className="container">
      <div className="form-container">
        {isRegistered ? (
          <>
            {/* Display a thank you message and a link to login after successful registration */}
            <div className="thankful-message">
              <h2>Thank you for registering on our website!</h2>
              <Link to="/login">Click here to login.</Link>
            </div>
          </>
        ) : (
          <>
            {/* Display the registration form */}
            <h1>Sign Up to Our Services</h1>
            <h3>Fill out this form to sign up to our services</h3>
            <div className="name-group">
              <div>
                <h2>First Name</h2>
                {/* Input field for first name */}
                <input
                  type="text"
                  id="firstName"
                  value={userValue.firstName}
                  onChange={myForm.handleChange}
                  pattern="[A-Za-z]+"
                  title="First name contains only letters"
                  required
                />
              </div>
              <div>
                <h2>Last Name</h2>
                {/* Input field for last name */}
                <input
                  type="text"
                  id="lastName"
                  value={userValue.lastName}
                  onChange={myForm.handleChange}
                  pattern="[A-Za-z]+"
                  title="Last name contains only letters"
                  required
                />
              </div>
            </div>
            <div className="address-group">
              <div>
                <h2>Street</h2>
                {/* Input field for street address */}
                <input
                  type="text"
                  id="street"
                  value={userValue.street}
                  onChange={myForm.handleChange}
                />
              </div>
              <div>
                <h2>City</h2>
                {/* Input field for city */}
                <input
                  type="text"
                  id="city"
                  value={userValue.city}
                  onChange={myForm.handleChange}
                  pattern="[A-Za-z]+"
                  title="City contains only letters"
                  required
                />
              </div>
              <div>
                <h2>Zip Code</h2>
                {/* Input field for zip code */}
                <input
                  type="text"
                  id="zipCode"
                  value={userValue.zipCode}
                  onChange={myForm.handleChange}
                  pattern="[0-9]+"
                  title="Zip code contains only numbers"
                  required
                />
              </div>
            </div>
            <h2>Email</h2>
            {/* Input field for email */}
            <input
              type="email"
              id="email"
              value={userValue.email}
              onChange={myForm.handleChange}
              required
            />

            <h2>Password</h2>
            {/* Input field for password */}
            <input
              type="password"
              id="password"
              value={userValue.password}
              onChange={myForm.handleChange}
              required
            />
            <div className="form-links">
              {/* Button to submit the registration form */}
              <button type="submit" onClick={myForm.handleSubmit}>
                Register
              </button>
              {/* Link to the login page for users who are already registered */}
              <Link to="/login">Already registered? Login here!</Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
