import React, { useState, useEffect } from "react";
import axios from "axios";
import { Tabs, Tab } from "@mui/material";
import PaypalButtonSrc from "./paypal.png";
import useForm from "../../hooks/useForm";
import formValidate from "../../utilities/formValidate";
import "./userProfile.css";
import { RiDeleteBin6Line } from "react-icons/ri";
import { BsCircleFill } from "react-icons/bs"; // Import the circle icon for color
import { useNavigate } from "react-router-dom";
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";

export default function UserProfile() {
  // State for managing tabs and cart
  const [selectedTab, setSelectedTab] = useState(1);

  const navigate = useNavigate();
  const [cart, setCart] = useState(
    JSON.parse(sessionStorage.getItem("cart") || "[]")
  );

  const [vatValue, setVatValue] = useState(
    parseFloat(sessionStorage.getItem("vatValue")) || 17
  );

  // State for managing profile editing
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [userData, setUserData] = useState({});
  const [userValue, setUserValue] = useState({
    firstName: "",
    lastName: "",
    street: "",
    city: "",
    zipCode: "",
    email: "",
  });

  // Function to fetch user data
  const fetchUserData = () => {
    // Fetch user data using the getUser service
    const user = JSON.parse(sessionStorage.getItem("user"));
    setUserData(user);

    setUserValue({
      firstName: user.First_Name,
      lastName: user.Last_Name,
      street: user.Street,
      city: user.City,
      zipCode: user.Zip,
      email: user.Email,
    });
  };

  useEffect(() => {
    fetchUserData();
  }, []);

  // Function to handle order placement
  const handleOrder = async () => {
    try {
      const response = await axios.post("http://localhost:3001/api/orders", {
        cart: cart,
        user: userData,
      });
      if (response.status === 200) {
        // Reduce product quantities in the database
        await Promise.all(
          cart.map(async (item) => {
            try {
              const updatedProduct = {
                ...item,
                Product_Amount: item.Product_Amount - item.quantity,
              };
              const updateResponse = await axios.put(
                `http://localhost:3001/api/products/${item.Product_ID}`,
                updatedProduct
              );
              if (updateResponse.status === 200) {
                console.log(
                  `Quantity updated for product ID ${item.Product_ID}`
                );
              }
            } catch (err) {
              console.log(err);
            }
          })
        );

        alert("Order placed successfully");
        sessionStorage.removeItem("cart");
        window.location.reload();
      }
    } catch (err) {
      alert(err.message);
      console.log(err);
    }
  };

  // Form handling using useForm custom hook
  const myForm = useForm([
    userValue,
    setUserValue,
    {
      onsubmit: async (event) => {
        event.preventDefault();
        const { isValid, errors } = formValidate(userValue);

        if (isValid) {
          try {
            const res = await axios.put(`api/users`, userValue);
            if (res.status === 200) {
              alert("User updated successfully");
              sessionStorage.setItem(
                "user",
                JSON.stringify({
                  First_Name: userValue.firstName,
                  Last_Name: userValue.lastName,
                  Street: userValue.street,
                  City: userValue.city,
                  Zip: userValue.zipCode,
                  Email: userValue.email,
                })
              );
            }
          } catch (err) {
            console.log(err);
            alert(err?.response?.data?.error || err.message);
          }
        } else {
          // Display error messages for invalid fields
          alert(Object.values(errors).join("\n"));
        }
      },
    },
  ]);

  // Calculate the total price of products in the cart
  const totalPrice = cart.reduce(
    (total, item) => total + parseFloat(item.Product_Price) * item.quantity,
    0
  );

  // Function to handle quantity change
  const handleQuantityChange = (productId, change) => {
    const updatedCart = cart.map((item) => {
      if (item.id === productId) {
        const newQuantity = item.quantity + change;
        if (newQuantity >= 1 && newQuantity <= item.Product_Amount) {
          return { ...item, quantity: newQuantity };
        }
      }
      return item;
    });

    sessionStorage.setItem("cart", JSON.stringify(updatedCart));
    setCart(updatedCart);
  };

  // Function to handle removing items from the cart
  const handleRemoveFromCart = (productId) => {
    const updatedCart = cart.filter((item) => item.id !== productId);
    sessionStorage.setItem("cart", JSON.stringify(updatedCart));
    setCart(updatedCart);
  };

  return (
    <div id="userProfile">
      {/* Tabs for user profile */}
      <Tabs
        value={selectedTab}
        onChange={(event, newValue) => setSelectedTab(newValue)}
        aria-label="User profile tabs"
      >
        <Tab
          label="Edit Profile"
          onClick={() => {
            setSelectedTab(0);
            setShowEditProfile(true);
          }}
          value={0}
        />
        <Tab
          label="My Orders"
          onClick={() => {
            navigate(`/user/orders/${userValue.email}`);
          }}
          value={0}
        />
      </Tabs>

      <div className="container">
        {/* Welcome message */}
        <div className="welcome-message">
          <p>
            Welcome, {userData.First_Name} {userData.Last_Name}
          </p>
        </div>
      </div>

      <div className="main">
        <div className="order-summary">{/* <h3>Order Summary</h3> */}</div>

        {/* Cart section */}
        <div id="cart" className="left-content">
          <h3>Order Summary</h3>
          <div id="cart-items">
            {/* Cart item */}
            <div className="cart-item"></div>
            {cart.map((item) => (
              <div className="cart-item" key={item.id}>
                <div className="cell">
                  <img src={item.Image_URL} alt={item.Product_Name} />
                </div>
                <div className="cell">{item.Product_Name}</div>
                <div className="cell">
                  ${item.Product_Price}
                  <div className="cell">
                    <BsCircleFill
                      className="color-icon"
                      style={{ color: item.Product_Color }}
                    />
                  </div>
                  <div className="cell">
                    {/* Quantity adjustment */}
                    <button
                      className="quantity-button"
                      onClick={() => handleQuantityChange(item.id, -1)}
                      disabled={item.quantity === 1}
                    >
                      <span className="quantity-button-icon">-</span>
                    </button>
                    <span className="quantity">{item.quantity}</span>
                    <button
                      className="quantity-button"
                      onClick={() => handleQuantityChange(item.id, 1)}
                      disabled={item.quantity === item.Product_Amount}
                    >
                      <span className="quantity-button-icon">+</span>
                    </button>
                    {/* Remove from cart */}
                    <div className="remove-button">
                      <button
                        className="remove-button"
                        onClick={() => handleRemoveFromCart(item.id)}
                      >
                        <RiDeleteBin6Line />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          {/* PayPal button */}
          <PayPalScriptProvider
            options={{
              "client-id":
                "ATluNhASBtKB7JFfZ_FtrYWSkOu_PZwwO6vEB-WeMDI7Ll4RiePEHrBVb12FbdB-LWstkOVBnG3-dHxt", // Replace with your PayPal client ID
            }}
          >
            <PayPalButtons
              createOrder={(data, actions) => {
                return actions.order.create({
                  purchase_units: [
                    {
                      amount: {
                        value: (totalPrice / (1 + vatValue / 100)).toFixed(2),
                      },
                    },
                  ],
                });
              }}
              onApprove={(data, actions) => {
                return actions.order.capture().then((details) => {
                  // Handle successful payment, e.g., call your `handleOrder` function.
                  handleOrder();
                });
              }}
            />
          </PayPalScriptProvider>
          {/* PayPal button and subtotal */}
          <div>
            {/* <img
              onClick={handleOrder}
              className="paypal"
              src={PaypalButtonSrc}
              alt="Pay with PayPal"
            /> */}
            {/* Display the VAT rate information */}
            <p className="vat-message">VAT: {vatValue}%</p>
            {/* Display the total price without the VAT value */}
            <p className="vat-message">
              Total Price (Excluding VAT) $
              {(totalPrice / (1 + vatValue / 100)).toFixed(2)}
            </p>
            <p>Subtotal ${totalPrice.toFixed(2)}</p>{" "}
            <button onClick={handleOrder} className="paypal-button">
              Submit Order
            </button>
          </div>
        </div>

        {/* Edit Profile form */}
        {showEditProfile && (
          <div className="form-container center-content">
            <h3>Your profile</h3>
            {/* Editable profile fields */}
            <div>
              <div>First Name</div>
              <input
                type="text"
                id="firstName"
                value={userValue.firstName}
                onChange={myForm.handleChange}
                pattern="[A-Za-z]+"
                title="First name contains only letters"
                required
              />
            </div>
            <div>
              <div>Last Name</div>
              <input
                type="text"
                id="lastName"
                value={userValue.lastName}
                onChange={myForm.handleChange}
                pattern="[A-Za-z]+"
                title="Last name contains only letters"
                required
              />
            </div>
            <div>
              <div>Street</div>
              <input
                type="text"
                id="street"
                value={userValue.street}
                onChange={myForm.handleChange}
              />
            </div>
            <div>
              <div>City</div>
              <input
                type="text"
                id="city"
                value={userValue.city}
                onChange={myForm.handleChange}
                pattern="[A-Za-z]+"
                title="City contains only letters"
                required
              />
            </div>
            <div>
              <div>Zip Code</div>
              <input
                type="text"
                id="zipCode"
                value={userValue.zipCode}
                onChange={myForm.handleChange}
                pattern="[0-9]+"
                title="Zip code contains only numbers"
                required
              />
            </div>
            <div>Email</div>
            <input
              type="email"
              id="email"
              value={userValue.email}
              onChange={myForm.handleChange}
              required
              disabled
              readOnly
            />
            {/* Form submission buttons */}
            <div className="form-links">
              <button type="submit" onClick={myForm.handleSubmit}>
                Update
              </button>
              <button onClick={() => setShowEditProfile(false)}>Close</button>
            </div>
          </div>
        )}
      </div>

      {/* Contact Information */}

      <div>
        <p id="p1">
          For any additional information, such as order updates or
          cancellations, please contact our customer service at{" "}
          <a href="tel:0508810991">050-881-0991 (WhatsApp)</a>.
        </p>
      </div>
      <div>
        <p id="p2">
          If you have questions about our products or need assistance with your
          purchase, our knowledgeable support team is here to help. Reach out to
          us via <a href="mailto:support@example.com">support@example.com</a>{" "}
          for quick responses.
        </p>
      </div>
      <div>
        <p id="p3">
          We value your feedback! Please let us know about your shopping
          experience or any suggestions you may have. Email us at{" "}
          <a href="mailto:feedback@example.com">feedback@example.com</a>. Your
          opinions matter.
        </p>
      </div>
      <div>
        <p id="p4">
          Our business hours are from Monday to Friday, 9:00 AM to 5:00 PM. If
          you need assistance outside of these hours, you can still send us an
          email or leave a message, and we'll get back to you as soon as we're
          available.
        </p>
      </div>
    </div>
  );
}
