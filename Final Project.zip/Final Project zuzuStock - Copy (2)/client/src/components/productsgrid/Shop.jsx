/*client/src/components/productsgrid/Shop.jsx */
import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import { Link } from "react-router-dom";
import "./Shop.css";
import axios from "axios"; // Import axios for making API requests
import { ProductsGrid } from "../category/ProductsGrid"; // Import the ProductsGrid component

// Define the functional component "Shop"
const Shop = () => {
  // Define state variables for categories and the selected category
  const [categories, setCategories] = useState([]);
  const [category, setCategory] = useState("");

  // Use the useEffect hook to fetch categories data from the server
  useEffect(() => {
    // Fetch categories data from the server using axios
    axios
      .get("/api/categories") // Use a relative URL to fetch data
      .then((res) => {
        setCategories(res.data.categories); // Update the categories state with the fetched data
        setCategory(res.data.categories[0].Category_Name); // Set the default selected category
      })
      .catch((err) => console.log(err));
  }, []); // The effect runs once when the component is mounted

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* Categories sidebar */}
      <div className="categories">
        <div className="container categoriesFlex">
          <ul>
            {/* Map through categories and render them as links */}
            {categories?.map((item) => {
              return (
                <li key={item.id}>
                  <Link
                    to=""
                    onClick={() => setCategory(item.Category_Name)} // Set the selected category when a link is clicked
                  >
                    {item.Category_Name}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
      {/* Display products from the selected category using the ProductsGrid component */}
      <ProductsGrid category={category} />
    </Box>
  );
};

export default Shop;
