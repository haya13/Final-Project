// Import necessary modules and components from Material-UI and React
import * as React from "react";
import { useState, useEffect } from "react";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
import { useNavigate, useLocation } from "react-router-dom";
import { Link } from "react-router-dom";

// Define an array of pages with their names and paths
const pages = [
  {
    name: "Home",
    path: "/",
  },
  {
    name: "Shop",
    path: "/shop",
  },

  {
    name: "About Us",
    path: "/about",
  },
  {
    name: "Register",
    path: "/Register",
  },
  {
    name: "Admin Dashboard",
    path: "/admin/dashboard",
  },
];

// Define the functional component "TopBar"
export default function TopBar() {
  // Check if the user is logged in based on sessionStorage
  const isLoggedIn =
    sessionStorage.getItem("isLoggedIn") === "true" ? true : false;
  const isAdmin =
    isLoggedIn &&
    JSON.parse(sessionStorage.getItem("user") || "{}").user_status === 0;

  const [userData, setUserData] = useState();
  const [buttonText, setButtonText] = useState(isLoggedIn ? "Logout" : "Login");

  // Get the current location using useLocation hook
  let location = useLocation();

  // State to track the selected tab's value
  const [value, setValue] = useState(
    pages.find((item) => {
      return item.path === location.pathname;
    })?.name
  );

  const navigate = useNavigate();

  // Function to handle user logout
  const handleLogout = () => {
    sessionStorage.removeItem("user");
    sessionStorage.removeItem("isLoggedIn");
    navigate("/");
  };

  // Function to handle user login/logout
  const handleLogin = () => {
    if (isLoggedIn) {
      handleLogout();
    } else {
      navigate("/login");
    }
  };

  // Function to handle tab change
  const handleChange = (event, newValue) => {
    console.log("newValue", newValue);
    setValue(newValue);
    const page = pages.find((item) => {
      return item.name === newValue;
    });
    navigate(page.path);
  };

  // Check if the user is logged in and retrieve user data from sessionStorage
  useEffect(() => {
    if (isLoggedIn) {
      // Note: You should set the user data properly here
      setUserData(userData);
      setButtonText("Logout");
    } else {
      setButtonText("Login");
    }
  }, [isLoggedIn]);

  return (
    <Box
      sx={{
        width: "100%",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        borderBottom: 1,
        borderColor: "divider",
      }}
    >
      <div style={{ display: "flex", alignItems: "center" }}>
        {/* Tabs for navigation */}
        <Tabs
          value={value}
          onChange={handleChange}
          aria-label="basic tabs example"
          sx={{ flexGrow: 1 }}
        >
          {pages.map((page, index) => {
            if (page.name === "Register" && isLoggedIn) return null;
            if (page.name === "Admin Dashboard" && !isAdmin) return null;

            return <Tab label={page.name} key={page.name} value={page.name} />;
          })}
        </Tabs>
      </div>

      <div style={{ display: "flex", alignItems: "center" }}>
        {/* Button for login/logout */}
        <button onClick={handleLogin}>{buttonText}</button>
        {/* Display user and shopping cart icons if the user is logged in */}
        {isLoggedIn && !isAdmin && (
          <Link to="/profile">
            <img
              src="/pictures/user.png"
              alt="user"
              style={{ width: "30px", height: "30px", marginLeft: "10px" }}
            />
          </Link>
        )}
        {isLoggedIn && (
          <Link to="/profile">
            <img
              src="/pictures/shopping-cart.png"
              alt="Shopping Cart"
              style={{ width: "30px", height: "30px", marginLeft: "10px" }}
            />
          </Link>
        )}
      </div>
    </Box>
  );
}
