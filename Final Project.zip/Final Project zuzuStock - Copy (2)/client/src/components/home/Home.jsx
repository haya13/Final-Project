// client/src/components/home/Home.jsx

import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./home.css";
import TopBar from "../top-bar/TopBar";

export default function Home() {
  // Define state variables for user authentication and user data
  const [loggedIn, setLoggedIn] = useState(false);
  const [userData, setUserData] = useState();
  // Use the "useNavigate" hook from "react-router-dom" to handle navigation
  let navigate = useNavigate();
  // Use the "useEffect" hook to run code when the component is mounted
  useEffect(() => {
    // Check if the user is logged in and retrieve user data from sessionStorage
    const isLoggedIn =
      sessionStorage.getItem("isLoggedIn") === "true" ? true : false;
    const userData = JSON.parse(sessionStorage.getItem("user"));
    // Update the state variables based on the retrieved data
    if (isLoggedIn) {
      setLoggedIn(isLoggedIn);
      setUserData(userData);
    }
  }, []);

  return (
    <div className="homepage">
 
      <div className="container bordered-container">
        <h1>Zuzu Stock - Warehouse Online Store</h1>
        <div className="welcome-container">
          <p>WELCOME</p>
        </div>
      </div>
      <div className="container categories-board">
        {/* Category cards with onClick handlers to navigate to the "/shop" route */}
        <div
          className="category-card"
          onClick={() => {
            navigate("/shop");
          }}
        >
          <p>Carpets</p>
          <img
            src="https://i.pinimg.com/474x/aa/44/eb/aa44eb19587a4d23cb751438e627bdce.jpg"
            alt=""
            className="category-card-img"
          ></img>
        </div>
        <div
          className="category-card"
          onClick={() => {
            navigate("/shop");
          }}
        >
          <p>Kitchenware</p>
          <img
            src="https://i.pinimg.com/564x/af/a6/a6/afa6a64421b0c66e494241b1bc9c616c.jpg"
            className="category-card-img"
          ></img>
        </div>
        <div
          className="category-card"
          onClick={() => {
            navigate("/shop");
          }}
        >
          <p>Interior Decor</p>
          <img
            src="https://i.pinimg.com/564x/1d/89/85/1d898577afaec027a9bd5bdd6e857adc.jpg"
            className="category-card-img"
          ></img>
        </div>
        <div
          className="category-card"
          onClick={() => {
            navigate("/shop");
          }}
        >
          <p>Furniture</p>
          <img
            src="https://i.pinimg.com/474x/e5/21/fc/e521fcf5527b0dee04c9261a0d71191b.jpg"
            className="category-card-img"
          ></img>
        </div>
        <div
          className="category-card"
          onClick={() => {
            navigate("/shop");
          }}
        >
          <p>Outdoors</p>
          <img
            src="https://i.pinimg.com/474x/db/86/4d/db864d626597456f34fa258c0a0b9a3e.jpg"
            className="category-card-img"
          ></img>
        </div>
        <div
          className="category-card"
          onClick={() => {
            navigate("/shop");
          }}
        >
          <p>Special Offers</p>
          <img
            src="https://i.pinimg.com/564x/28/29/28/282928b853c7ad0db272fcbe3aa6d48f.jpg"
            className="category-card-img"
          ></img>
        </div>
      </div>
    </div>
  );
}
