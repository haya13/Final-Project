import React from "react";
import "./footer.css";

const Footer = () => {
  return (
    // Render the footer content within a container div with a specified class name

    <div className="footer-container">
      {/* Display the current year using JavaScript's Date object */}

      <h5>
        &copy; {new Date().getFullYear()}
        {/* Display the text "Zuzu Stock" */}
        <span> Zuzu Stock</span>
      </h5>
      {/* Display the text "All Rights reserved" */}
      <h5>All Rights reserved</h5>
    </div>
  );
};

export default Footer;
