/**client/src/components/productcard/productCard.jsx */
import * as React from "react";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import "./productcard.css";
import { Box, Modal } from "@mui/material";
import { useNavigate } from "react-router-dom";

// Define the style for the Modal component
const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};
// Define the functional component "ProductCard" that receives a "product" prop
export function ProductCard({ product }) {
  const [open, setOpen] = React.useState(false); // State to control the Modal
  const handleOpen = () => setOpen(true); // Function to open the Modal
  const handleClose = () => setOpen(false); // Function to close the Modal
  const navigate = useNavigate(); // Hook for navigation
  const [addedToCart,setAddedToCart] = React.useState(false); // State to track if the product is added to the cart

  // Function to handle the "Buy now" button click
  const handleBuyNow = () => {
    const isLoggedIn = sessionStorage.getItem("isLoggedIn") === "true";
    if (!isLoggedIn) {
      navigate("/login"); // Redirect to the login page if the user is not logged in
      return;
    }

    if (product.Product_Amount > 0) {
      const cart = JSON.parse(sessionStorage.getItem("cart") || "[]");
      const index = cart.findIndex((cartItem) => cartItem.id === product.id);

      if (index > -1) {
        cart[index].quantity += 1;
      } else {
        cart.push({ ...product, quantity: 1 });
      }
      sessionStorage.setItem("cart", JSON.stringify(cart)); // Update the cart in sessionStorage
      setAddedToCart(true); // Set addedToCart state to true to indicate successful addition to the cart
      alert("Added to Cart");
    } else {
      alert("This product is out of stock.");
    }
  };
  return (
    <>
      {/* Product Card */}
      <Card
        sx={{
          maxWidth: 345,
          minWidth: 300,
          backgroundColor: "var(--lion);",
          color: "var(--platinum);",
        }}
      >
        {/* CardContent to hold the product details */}
        <CardContent>
          {/* Product name */}
          <Typography gutterBottom variant="h5" component="div">
            {product.Product_Name}
          </Typography>
          {/* Product price */}
          <Typography gutterBottom variant="h5" component="div">
            {product.Product_Price}$
          </Typography>

          {product.Image_URL ? (
            <img
              src={product.Image_URL} // Assuming you have the Image_URL field in your product object
              alt={"aa"}
              className="product-image"
            />
          ) : null}
        </CardContent>
        {/* CardActions to hold the action buttons */}
        <CardActions>
          {/* Button to buy the product */}
          <Button size="small" onClick={handleBuyNow}>
            Buy now
          </Button>
          {/* Button to view more information about the product */}
          <Button size="small" onClick={handleOpen}>
            More info
          </Button>
        </CardActions>
      </Card>
      {/* Modal for displaying more product information */}

      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            {product.Product_Name}
          </Typography>
          {/* Display the image in the modal */}
          {product.Image_URL ? (
            <img
              src={product.Image_URL}
              alt={product.Product_Name}
              className="modal-product-image"
              style={{ width: "100%", height: "auto" }}
            />
          ) : null}
          <Typography gutterBottom variant="h5" component="div"></Typography>
          {/* Product price */}
          <Typography gutterBottom variant="h5" component="div">
            {product.Product_Price}$
          </Typography>
          {/* Product description */}
          <Typography variant="body2">{product.Product_Description}</Typography>
          <Typography variant="body2">
            Amount in Stock:{" "}
            {product.Product_Amount <= 0
              ? "Out of Stock"
              : product.Product_Amount}
          </Typography>
          <Typography variant="body2">
            Color:{" "}
            <span
              style={{
                color:
                  product.Product_Color.toLowerCase() === "white"
                    ? "black"
                    : product.Product_Color.toLowerCase(),
                fontWeight: "bold",
              }}
            >
              {product.Product_Color}
            </span>
          </Typography>
        </Box>
      </Modal>
    </>
  );
}
