/* client/src/components/login/Login.jsx */
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./login.css";
import useForm from "../../hooks/useForm";
import { loginUser } from "../../services/userService";
import TopBar from "../top-bar/TopBar";

export default function Login() {
  const navigate = useNavigate();
  // Define state for user input (email and password)
  const [userValue, setUserValue] = useState({
    email: "",
    password: "",
  });
  // Use the custom "useForm" hook to handle form input and submission
  const myForm = useForm([
    userValue,
    setUserValue,
    {
      onsubmit: (event) => {
        event.preventDefault();
        // Call the "loginUser" function from the user service to authenticate the user
        loginUser(userValue)
          .then(({ user_status, user }) => {
            console.log("Server response:", user_status, user);

            // Store user data in sessionStorage upon successful login
            sessionStorage.setItem("user", JSON.stringify(user));
            sessionStorage.setItem("isLoggedIn", "true");
            // Redirect the user based on their status (admin or customer)
            if (user_status === 0) {
              navigate("/admin/dashboard"); // Admin goes to dashboard
            } else {
              navigate("/profile"); // Customer goes to profile page
            }
          })

          .catch((err) => console.log(err));
      },
    },
  ]);
  // Function to navigate to the home page
  const handleGoHome = () => {
    console.log("Navigating to the home page");
    navigate("/"); // Navigate to the home page
  };

  return (
    
    <div id="login" className="container d-flex-column no-scroll">
     
      <h1>Welcome Back!</h1>
      <p>Please log in to your account</p>
      <form className="d-flex-column" onSubmit={myForm.handleSubmit}>
        {/* Input field for the email */}

        <label>Email:</label>
        <input
          type="email"
          id="email"
          value={userValue.email}
          onChange={myForm.handleChange}
        />
        {/* Input field for the password */}

        <label>Password:</label>
        <input
          type="password"
          id="password"
          value={userValue.password}
          onChange={myForm.handleChange}
        />
        {/* Submit button to log in */}

        <button type="submit">Login</button>
        <button type="button" onClick={handleGoHome}>
          Go to Home Page
        </button>
      </form>
      {/* Link to the registration page */}
      <Link to="/register">Don't have an account? Register here!</Link>
    </div>
  );
}
