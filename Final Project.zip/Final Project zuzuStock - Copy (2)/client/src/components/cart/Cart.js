// client/src/components/cart/Cart.js
import React from "react";

function Cart({ cartItems }) {
  const totalAmount = cartItems.reduce(
    (sum, item) => sum + item.Product_Price,
    0
  );

  return (
    <div>
      <h2>Your Cart</h2>
      <ul>
        {cartItems.map((item, index) => (
          <li key={index}>
            {item.Product_Name} - ${item.Product_Price} - Final Price: $
            {item.Final_Price}
          </li>
        ))}
      </ul>
      <p>Total: ${totalAmount.toFixed(2)}</p>
    </div>
  );
}

export default Cart;
