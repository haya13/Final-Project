// client/src/components/cart/CartPage.js
import React from "react";
import Cart from "./Cart"; // Assuming you have a Cart component similar to before

function CartPage({ cartItems }) {
  const totalAmount = cartItems.reduce(
    (sum, item) => sum + item.Product_Price,
    0
  );

  return (
    <div>
      <h2>Your Cart</h2>
      <Cart cartItems={cartItems} />
      <p>Total: ${totalAmount.toFixed(2)}</p>
    </div>
  );
}

export default CartPage;
