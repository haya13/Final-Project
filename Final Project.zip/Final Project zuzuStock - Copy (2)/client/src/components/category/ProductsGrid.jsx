/*client\src\components\category\ProductsGrid.jsx */
import React, { useEffect, useState } from "react";
import "./ProductsGrid.css";
import axios from "axios";
import Grid from "@mui/material/Grid";
import { ProductCard } from "../productcard/ProductCard";
// Define a functional component named "ProductsGrid" that takes a "category" prop
export function ProductsGrid({ category }) {
  // Define a state variable "products" to store the fetched products
  const [products, setProducts] = useState([]);
  // Use the useEffect hook to fetch products when the "category" prop changes
  useEffect(() => {
    // Fetch products by category using axios
    axios
      .get(`/api/products/${category}`) // Use relative URL
      .then((res) => {
        console.log("Fetched products:", res.data.products); // Log fetched products
        setProducts(res.data.products);
      })
      .catch((err) => {
        console.log(err); // The effect runs whenever "category" prop changes
      });
  }, [category]); // The effect runs whenever "category" prop changes

  // Render the component's UI
  return (
    <Grid
      container
      spacing={{ xs: 2, md: 3 }}
      columns={{ xs: 4, sm: 8, md: 12 }}
    >
      {/* Map through the "products" array and render a "ProductCard" component for each product */}

      {products?.map((product, index) => (
        <Grid
          item
          display="flex"
          justifyContent="center"
          alignItems="center"
          xs={2}
          sm={4}
          md={4}
          key={index} // Use the "index" as the key for each product (ideally, use a unique identifier from the data)
        >
          {/* Render the "ProductCard" component with the "product" data */}
          <ProductCard key={product.id} product={product} />
        </Grid>
      ))}
    </Grid>
  );
}
