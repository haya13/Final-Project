export const checkIsAdmin = () => {
  const user = JSON.parse(sessionStorage.getItem("user"));
  if (user && user.user_status === 0) {
    return true;
  }
  return false;
};
