// client/src/utilities/sessionHelper.js
/**
 * Clears user-related session data, including user information and login status.
 */

export function clearSession() {
  sessionStorage.removeItem("user"); // Remove user information from session storage
  sessionStorage.removeItem("isLoggedIn"); // Remove the login status from session storage
}
