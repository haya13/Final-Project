/**client/src/utilities/formValidate.js*/

const formValidate = (values) => {
  const errors = {};

  // Define regular expression patterns
  const namePattern = /^[A-Za-z]+$/;
  const streetPattern = /^[A-Za-z]+[0-9A-Za-z]*$/;
  const cityPattern = /^[A-Za-z]+$/;
  const zipCodePattern = /^[0-9]+$/;
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const passwordPattern = /^[A-Za-z0-9]{8,}$/;

  // Validate First Name
  if (!namePattern.test(values.firstName)) {
    errors.firstName = "First Name should contain only letters.";
  }

  // Validate Last Name
  if (!namePattern.test(values.lastName)) {
    errors.lastName = "Last Name should contain only letters.";
  }

  // Validate Street
  if (!streetPattern.test(values.street)) {
    errors.street = "Street should start with letters and may contain numbers.";
  }

  // Validate City
  if (!cityPattern.test(values.city)) {
    errors.city = "City should contain only letters.";
  }

  // Validate Zip Code
  if (!zipCodePattern.test(values.zipCode)) {
    errors.zipCode = "Zip Code should contain only numbers.";
  }

  // Validate Email
  if (!emailPattern.test(values.email)) {
    errors.email = "Invalid email format.";
  }

  // Validate Password
  if (!passwordPattern.test(values.password)) {
    errors.password =
      "Password should contain only letters and numbers with a minimum length of 8 characters.";
  }

  // Determine if the form is valid (no errors)
  const isValid = Object.keys(errors).length === 0;

  return { isValid, errors };
};

export default formValidate;
