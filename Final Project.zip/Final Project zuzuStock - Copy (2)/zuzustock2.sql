DROP DATABASE IF EXISTS `zuzustock`;
CREATE DATABASE `zuzustock`;
USE `zuzustock`;


--
-- Database: `zuzustock`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Category_Name` varchar(15) NOT NULL,
  `Category_Products` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Category_Name`, `Category_Products`) VALUES
('Carpets', ''),
('Furniture', ''),
('Interior Decor', ''),
('Kitchenware', ''),
('Outdoors', ''),
('Sales', '');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `First_Name` varchar(20) NOT NULL,
  `Last_Name` varchar(20) NOT NULL,
  `City` varchar(50) NOT NULL,
  `Street` varchar(150) NOT NULL,
  `Zip` int(10) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `user_status` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`First_Name`, `Last_Name`, `City`, `Street`, `Zip`, `Email`, `Password`, `user_status`) VALUES
('Alaa', 'Masoud', 'Haifa', 'Amos', 123456, 'alaamas@gmail.com', '$2b$10$7qJ9rDco4ZLcMYr1mTN4/O94eKYGvDbJDJNmOzdnVPg5ZGIxunmWe', 1),
('Donia', 'Sager', 'Shfaraam', 'Medan', 2020000, 'Donia-sager@hotmail.com', '$2b$10$7qJ9rDco4ZLcMYr1mTN4/O94eKYGvDbJDJNmOzdnVPg5ZGIxunmWe', 1),
('Haya', 'Masoud', 'Ara', 'Alshafei', 3002500, 'hayamasoud099@gmail.com', '$2b$10$7qJ9rDco4ZLcMYr1mTN4/O94eKYGvDbJDJNmOzdnVPg5ZGIxunmWe', 0),
('Mohammed', 'Masoud', 'Arara', 'Arara13', 3002600, 'hmody2003@gmail.com', '$2b$10$nIb7v2Tt1YvvfCXX6m5Z1Osq0UoE3MjaEe4Sz.vQiXiz9ZcohmCJe', 1),
('Mona', 'Younis', 'Ara', 'Alshafei', 3002500, 'monayounis1973@gmail.com', '$2b$10$7qJ9rDco4ZLcMYr1mTN4/O94eKYGvDbJDJNmOzdnVPg5ZGIxunmWe', 1),
('Nagham', 'Alasaad', 'Taybe', 'Taybe15', 789456, 'naghamalasaad12@gmail.com', '$2b$10$7qJ9rDco4ZLcMYr1mTN4/O94eKYGvDbJDJNmOzdnVPg5ZGIxunmWe', 1),
('Sawsan', 'Masalha', 'Kfarqarea', 'Albaten', 987541, 'Sawsan@gmail.com', '$2b$10$b0zyrhYgYvynTxzs7LNiYODEYQ8KLQ6XqFBt.DPh4oHXdQ07Cw5sm', 1);

-- --------------------------------------------------------

--
-- Table structure for table `director`
--

CREATE TABLE `director` (
  `UserName` varchar(15) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `Order_Date` varchar(1115) NOT NULL,
  `Final_Price` varchar(18) NOT NULL,
  `Destination_Address` varchar(150) NOT NULL,
  `TotalItemsQuantity` varchar(18) NOT NULL,
  `Order_Owner` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `Order_Date`, `Final_Price`, `Destination_Address`, `TotalItemsQuantity`, `Order_Owner`) VALUES
(1, '2023-08-15 14:37:10.040', '99.97999999999999', 'Medan, Shfaraam, 2020000', '2', 'Donia-sager@hotmail.com'),
(5, '2023-08-19 21:12:38.869', '379.97', 'Taybe15, Taybe, 789456', '3', 'naghamalasaad12@gmail.com'),
(6, '2023-08-19 23:35:05.642', '79.99', 'Alshafei, Ara, 3002500', '1', 'monayounis1973@gmail.com'),
(7, '2023-08-19 23:35:43.719', '1469.96', 'Albaten, Kfarqarea, 987541', '5', 'Sawsan@gmail.com'),
(9, '2023-08-20 14:07:59.101', '245.97000000000003', 'Medan, Shfaraam, 2020000', '3', 'Donia-sager@hotmail.com'),
(10, '2023-08-21 09:16:40.918', '0', 'Medan, Shfaraam, 2020000', '0', 'Donia-sager@hotmail.com'),
(11, '2023-08-22 12:31:59.714', '1378.98', 'Albaten, Kfarqarea, 987541', '3', 'Sawsan@gmail.com'),
(12, '2023-08-22 13:09:31.052', '99.97999999999999', 'Medan, Shfaraam, 2020000', '2', 'Donia-sager@hotmail.com'),
(13, '2023-08-22 16:49:14.678', '54.99', 'Alshafei, Ara, 3002500', '1', 'monayounis1973@gmail.com'),
(14, '2023-08-23 22:52:23.334', '0', 'Arara13, Arara, 3002600', '0', 'hmody2003@gmail.com'),
(15, '2023-08-23 23:18:08.242', '479.94', 'Medan, Shfaraam, 2020000', '6', 'Donia-sager@hotmail.com'),
(16, '2023-08-26 19:04:16.415', '299.98', 'Alshafei, Ara, 3002500', '2', 'monayounis1973@gmail.com');

-- --------------------------------------------------------

CREATE TABLE `order_details` (
  `order_id` INT,
  `item_id` VARCHAR(1000),
  `quantity` INT
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `order_details` (`order_id`, `item_id`,`quantity`)
VALUES
(1, 'CAR008', 1), 
(5, 'CAR008', 1), 
(6, 'CAR008', 1), 
(7, 'CAR008', 1), 
(9, 'CAR008', 1), 
(10, 'CAR008', 1), 
(11, 'CAR008', 1), 
(12, 'CAR008', 1), 
(13, 'CAR008', 1), 
(14, 'CAR008', 1), 
(15, 'CAR008', 1), 
(16, 'CAR008', 1);

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` varchar(15) NOT NULL,
  `Product_Name` varchar(30) NOT NULL,
  `Product_Price` varchar(8) NOT NULL,
  `Product_Color` varchar(20) NOT NULL,
  `Product_Amount` varchar(5) NOT NULL,
  `Product_Description` varchar(500) NOT NULL,
  `Category` varchar(1000) NOT NULL,
  `Image_URL` varchar(255) DEFAULT NULL,
  `isOnSale` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `Product_Name`, `Product_Price`, `Product_Color`, `Product_Amount`, `Product_Description`, `Category`, `Image_URL`, `isOnSale`) VALUES
('CAR002', 'Framed Wall Mirror', '10.99', 'Silver', '2', 'Grab this mirror now at an unbeatable price of just $10! Hurry, it\'s at its lowest stock level.', 'Sales', 'https://i.pinimg.com/474x/1d/30/75/1d3075a44de8ad5c28343bb44c2f4310.jpg', 0),
('CAR003', 'Vintage Floral Rug', '79.99', 'Pink', '1', 'Embrace a vintage look with this beautiful floral rug. Adds character to any room in your home.', 'Carpets', 'https://i.pinimg.com/474x/71/2a/7e/712a7e27d191f1a74af64a9f2fca5ee0.jpg', 0),
('CAR004', 'Faux Fur Area Rug', '34.99', 'White', '30', 'Experience luxury and warmth with this faux fur area rug. Perfect for creating a cozy ambiance.', 'Carpets', 'https://i.pinimg.com/474x/50/47/9a/50479a555cb5bd02d09842a8bae48a4f.jpg', 0),
('CAR005', 'Bohemian Fringe Rug', '64.99', 'Pink', '19', 'Embrace bohemian chic with this vibrant fringe rug. Adds personality to any living space.', 'Carpets', 'https://i.pinimg.com/474x/e0/d4/c3/e0d4c3ff4e6264bb5c26996cb84a9296.jpg', 0),
('CAR006', 'Moroccan Trellis Rug', '69.99', 'Pink', '8', 'Infuse your space with exotic flair using this Moroccan trellis rug. The navy blue and ivory color combination adds sophistication and elegance to any room.', 'Carpets', 'https://i.pinimg.com/474x/9c/3e/c9/9c3ec9e08e7351b96675adbf678c0f27.jpg', 0),
('CAR008', 'Boho Tassel Rug', '54.99', 'Black', '12', 'Add a bohemian touch to your space with this vibrant tassel rug. The multi-color design brings a lively and eclectic vibe to your room.', 'Carpets', 'https://i.pinimg.com/474x/a4/fc/bd/a4fcbddddb3212ceee747c82eaca54f3.jpg', 0),
('CAR009', 'Modern Striped Carpet', '64.99', 'Gold', '19', 'Create a contemporary look with this modern striped carpet. The gray and white stripes offer a sleek and minimalist aesthetic.', 'Carpets', 'https://i.pinimg.com/474x/77/f5/40/77f5406170c9175210042843bf56f208.jpg', 0),
('CAR011', 'Oriental Medallion Rug', '89.99', 'Blue', '7', 'Bring classic elegance to your space with this oriental medallion rug. The navy blue and gold accents exude timeless beauty.', 'Carpets', 'https://i.pinimg.com/474x/be/fe/61/befe61c6b500d8192129d60ce273da08.jpg', 0),
('DEC001', 'Elegant Velvet Sofa', '899.99', 'Green', '3', 'Transform your living space with this luxurious velvet sofa. Its deep blue color and elegant design will add a touch of sophistication to your home.', 'Interior Decor', 'https://i.pinimg.com/474x/a5/0e/ac/a50eac47ca7267d51476cb26cf7e0d39.jpg', 0),
('DEC002', 'Modern Geometric Wall Art', '49.99', 'Gold', '15', 'Elevate your walls with this stunning geometric wall art. The combination of black and gold adds a contemporary flair to any room.', 'Interior Decor', 'https://i.pinimg.com/474x/ba/c8/d8/bac8d8f550b4797c50113d8062d2be50.jpg', 0),
('DEC003', 'Rustic Wooden Coffee Table', '249.99', 'red', '11', 'Add a rustic charm to your living area with this wooden coffee table. Its natural wood finish and sturdy design make it both functional and stylish.', 'Interior Decor', 'https://i.pinimg.com/474x/b3/3b/c1/b33bc10c67d1d5a7fe8d0fc5c20a2509.jpg', 0),
('DEC004', 'Crystal Chandelier', '179.99', 'Gold', '7', 'Illuminate your space with elegance using this sparkling crystal chandelier. Its timeless design and clear crystals create a dazzling focal point.', 'Interior Decor', 'https://i.pinimg.com/474x/49/2f/c4/492fc4e69fc9ad50babfe7d4ae27eee6.jpg', 0),
('DEC005', 'Crystal Chandelier Bohemian Th', '39.99', 'Silver', '21', 'Infuse your home with bohemian vibes using this set of colorful throw pillows. Mix and match to create a cozy and vibrant atmosphere.', 'Interior Decor', 'https://i.pinimg.com/474x/fa/b9/a2/fab9a2d83fadee740115f589f6e24093.jpg', 0),
('DEC006', 'Minimalist Bookshelf', '149.99', 'red', '18', 'Keep your books and decor items organized with this sleek minimalist bookshelf. Its clean design and white color blend seamlessly with any interior.', 'Interior Decor', 'https://i.pinimg.com/474x/74/1b/a7/741ba708b89a0401d6569cebd576066f.jpg', 0),
('FUR001', 'Modern Sectional Sofa', '799.99', 'Grey', '10', 'Upgrade your living room with this sleek and comfortable modern sectional sofa.', 'Furniture', 'https://i.pinimg.com/474x/0d/97/b7/0d97b7e11d0dd7749a685dea480bac30.jpg', 0),
('FUR002', 'Mid-Century Dining Set', '499.99', 'Brown', '15', 'Add a touch of retro charm with this mid-century dining set. Perfect for family gatherings.', 'Furniture', 'https://i.pinimg.com/474x/88/15/2f/88152f5d1aed95a558fe1052345084e4.jpg', 0),
('FUR003', 'Storage Ottoman Bench', '129.99', 'Gray', '20', 'Maximize your storage space with this versatile ottoman bench. Ideal for entryways and bedrooms.', 'Furniture', 'https://i.pinimg.com/474x/18/e2/95/18e29599cf6667955fb9d875b4e55549.jpg', 0),
('FUR004', ' Industrial Coffee Table', '189.99', 'Black', '9', ' Accentuate your living room with this stylish industrial coffee table. Perfect for a rustic look.', 'Furniture', 'https://i.pinimg.com/474x/49/77/c0/4977c0dff9eab85a8d856745f0234f98.jpg', 0),
('FUR005', 'Upholstered Bed Frame', '449.99', 'Pink', '0', 'Sleep in luxury with this elegant upholstered bed frame. Creates a sophisticated bedroom atmosphere.', 'Furniture', 'https://i.pinimg.com/474x/8a/f7/49/8af749b2d69e13af20523a1bd736cd50.jpg', 0),
('FUR006', 'Office Desk with Hutch', '379.95', 'red', '9', 'An office desk featuring a built-in hutch for additional storage and organization.', 'Furniture', 'https://i.pinimg.com/474x/cf/c0/d5/cfc0d5b20b826d2a522ffd31205e2a36.jpg', 0),
('KIT001', 'Stainless Steel Cookware Set', '199.99', 'Pink', '10', 'Elevate your cooking experience with this stainless steel cookware set. The sleek silver design and durable construction make it a must-have for your kitchen.', 'Kitchenware', 'https://i.pinimg.com/474x/20/5b/1a/205b1abbd21616f5831daae81e5d950c.jpg', 0),
('KIT002', 'Non-Stick Baking Pan Set', '39.99', 'Black', '13', 'Bake with ease using this non-stick baking pan set. The black finish ensures even baking and easy food release, making it perfect for desserts and savory dishes.', 'Kitchenware', 'https://i.pinimg.com/474x/2b/c9/84/2bc984e39565da2833ee3b04d215d707.jpg', 0),
('KIT003', 'Ceramic Knife Set', '49.99', 'red', '0', 'Upgrade your culinary tools with this ceramic knife set. The sharp white blades and ergonomic handles offer precision and comfort while cutting.', 'Kitchenware', 'https://i.pinimg.com/474x/7b/ac/52/7bac5285d8ffe6afafa3cbefe7520f32.jpg', 0),
('KIT004', 'Glass Food Storage Containers', '29.99', 'Silver', '9', 'Keep your leftovers fresh with these clear glass food storage containers. The airtight lids and stackable design make organization a breeze.', 'Kitchenware', 'https://i.pinimg.com/474x/c7/35/2e/c7352e2cfda3264c76b3f387d6449868.jpg', 0),
('KIT005', 'Manual Coffee Grinder', '34.99', 'Green', '0', 'Enjoy freshly ground coffee at home with this electric coffee grinder. The stainless steel construction and adjustable settings ensure the perfect grind every time.', 'Kitchenware', 'https://i.pinimg.com/474x/b6/45/aa/b645aa76d3227e1aa39e70b782912f8a.jpg', 0),
('KIT006', 'Silicone Cooking Utensil Set', '24.99', 'Green', '21', 'Enhance your cooking prowess with this versatile silicone utensil set. The vibrant multicolor collection includes everything you need for efficient and scratch-resistant cooking.', 'Kitchenware', 'https://i.pinimg.com/474x/01/e3/d5/01e3d5de48ae8cd3f1e6713e89b68512.jpg', 0),
('OUT001', 'Camping Tent', '149.99', 'red', '6', 'A spacious camping tent designed for outdoor adventures, featuring easy setup and durable materials.', 'Outdoors', 'https://i.pinimg.com/474x/9d/40/ca/9d40ca81ba26ec0e19d2138206dba10d.jpg', 0),
('OUT003', 'Waterproof Hiking Backpack', '79.99', 'Blue', '15', 'A rugged hiking backpack with multiple compartments and waterproof features, ideal for long hikes and treks.', 'Outdoors', 'https://i.pinimg.com/474x/1b/58/e7/1b58e761f4292fdf5223c0ceafef87ba.jpg', 0),
('OUT004', 'Stainless Steel Water Bottle', '19.50', 'Green', '35', 'A durable and leak-proof stainless steel water bottle, suitable for keeping beverages cold or hot during outdoor activities.', 'Outdoors', 'https://i.pinimg.com/474x/59/df/41/59df41f6254c1f7531a8fc85f5ca5c4c.jpg', 0),
('OUT005', 'Portable Gas Grill', '129.00', 'Red', '10', 'A compact and easy-to-use portable gas grill, perfect for outdoor barbecues and camping cookouts.', 'Outdoors', 'https://i.pinimg.com/474x/1a/f2/c9/1af2c90f224ca8656bfced1e2d762683.jpg', 0),
('OUT006', 'Solar-Powered Portable Charger', '49.99', 'Green', '32', 'A compact and lightweight solar-powered charger, ideal for recharging devices like smartphones and tablets while on outdoor adventures.', 'Outdoors', 'https://i.pinimg.com/474x/e5/49/2a/e5492a9363d1c85233840ead42e50af6.jpg', 0),
('OUT007', 'Picnic Blanket', '10.99', 'Yellow', '16', 'A lightweight and foldable picnic blanket, perfect for enjoying outdoor picnics, gatherings, and relaxation.', 'Outdoors', 'https://i.pinimg.com/474x/07/4a/38/074a3858862842fe5260b2a4bc21e3c6.jpg', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Category_Name`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`First_Name`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
